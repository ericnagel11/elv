"""Channel orchestrator: the A2A client that drives one member turn end to end.

  member -> Intake Agent -> Disambiguation Agent -> Dispatch Agent -> Benefits Agent
                                    |                     +-> Live advocate queue
                                    +-> one clarifying question (A2A task input-required)

The orchestrator holds no benefit logic. It stores chat history (PHI-stripped) and
the pending clarification task so the member's reply continues the same A2A task.
"""
from __future__ import annotations

import time

import config
from a2a_protocol.protocol import (A2AClient, A2AClientError, TaskState, artifact_data, data_part,
                                   get_data, get_text, make_message, text_part)
from core import data_store
from core.store import Store

UNAVAILABLE_TEXT = ("I\u2019m having trouble reaching our benefits service right now, so I won\u2019t guess. "
                    "Please try again in a moment or call Member Services.")


class Orchestrator:
    def __init__(self, store: Store, intake_url: str, disambiguation_url: str, dispatch_url: str, benefits_url: str):
        self.store = store
        self.urls = {"intake": intake_url, "disambiguation": disambiguation_url,
                     "dispatch": dispatch_url, "benefits": benefits_url}

    def agent_cards(self) -> list[dict]:
        cards = []
        for key, url in self.urls.items():
            try:
                card = A2AClient(url).get_agent_card()
                cards.append({"key": key, "online": True, "url": url, "card": card})
            except A2AClientError as exc:
                cards.append({"key": key, "online": False, "url": url, "error": str(exc)})
        return cards

    def _history(self, sid: str) -> list[dict]:
        msgs = [m for m in self.store.messages(sid) if m["role"] in ("member", "assistant")]
        return [{"role": m["role"], "text": m["text"]} for m in msgs][-2 * config.CHAT_HISTORY_TURNS:]

    def handle_turn(self, sid: str, raw_text: str) -> dict:
        session = self.store.get_session(sid)
        if session is None:
            raise KeyError("session not found")
        started = time.perf_counter()
        exchanges: list[dict] = []
        rec = exchanges.append
        intake = A2AClient(self.urls["intake"], "Orchestrator", recorder=rec)
        disamb = A2AClient(self.urls["disambiguation"], "Orchestrator", recorder=rec)
        dispatch = A2AClient(self.urls["dispatch"], "Orchestrator", recorder=rec)
        history = self._history(sid)
        pending = session.get("pending")

        try:
            # 1-2. Capture + interpret
            itask = intake.send_message(make_message(
                "user", [text_part(raw_text), data_part({"sessionId": sid, "memberId": session["member_id"],
                                                          "channel": "web-chat"})], context_id=sid))
            if itask["status"]["state"] != TaskState.COMPLETED:
                return self._reply(sid, raw_text, None, get_text(itask["status"].get("message")) or UNAVAILABLE_TEXT,
                                   {"outcome": "rejected", "exchanges": exchanges}, started)
            env = artifact_data(itask, "intake-envelope")
            redacted = env["redactedUtterance"]

            # A new, clearly different question while a clarification is pending cancels the old task
            if pending and env["signals"].get("detectedConcept") and env["signals"]["detectedConcept"] != pending["conceptId"]:
                try:
                    disamb.cancel_task(pending["taskId"])
                except A2AClientError:
                    pass
                self.store.set_pending(sid, None)
                pending = None

            if not pending and env["utteranceType"] in ("greeting", "help", "context"):
                return self._reply(sid, raw_text, redacted, env["reply"],
                                   {"outcome": env["utteranceType"], "agent": "Intake Agent", "intake": env,
                                    "exchanges": exchanges}, started)

            # 3-6. Ground, enrich, prompt, resolve (continue the same A2A task after a clarification)
            dreq = {"skill": "resolveBeforeDispatch", "utterance": redacted, "normalized": env["normalized"],
                    "signals": env["signals"], "redactionCount": env["redactionCount"], "sessionId": sid,
                    "chatHistory": history, "memberContext": env["memberContext"],
                    "memoryRefs": {"topK": config.VECTOR_TOP_K},
                    "ontologyVersion": data_store.ontology()["version"], "policyTags": ["PHI-stripped"],
                    "confidenceThreshold": config.CONFIDENCE_THRESHOLD, "maxClarifications": config.MAX_CLARIFICATIONS,
                    "targetAgent": "benefits", "dispatchState": "awaiting-disambiguation"}
            dtask = disamb.send_message(make_message("user", [data_part(dreq)], context_id=sid,
                                                     task_id=pending["taskId"] if pending else None))
            resolution = artifact_data(dtask, "disambiguation-result")
            # use the latest artifact (a continued task holds one per attempt)
            arts = [a for a in dtask.get("artifacts", []) if a["name"] == "disambiguation-result"]
            if arts:
                resolution = get_data(arts[-1])

            if dtask["status"]["state"] == TaskState.INPUT_REQUIRED:
                self.store.set_pending(sid, {"taskId": dtask["id"], "conceptId": resolution["conceptId"],
                                             "slot": resolution["clarificationSlot"]})
                return self._reply(sid, raw_text, redacted, resolution["clarification"],
                                   {"outcome": "clarification", "agent": "Disambiguation Agent", "intake": env,
                                    "resolution": resolution, "exchanges": exchanges}, started)
            self.store.set_pending(sid, None)

            # 7. Respond: dispatch to Benefits Agent or transfer to live advocate
            ptask = dispatch.send_message(make_message("user", [data_part({
                "resolution": resolution, "memberContext": env["memberContext"], "sessionId": sid,
                "utterance": redacted, "chatHistory": history})], context_id=sid))
            result = artifact_data(ptask, "dispatch-result")
            exchanges.extend(result.get("downstreamExchanges", []))
            agent = "Benefits Agent" if result.get("outcome") == "answered" else "Dispatch Agent"
            return self._reply(sid, raw_text, redacted, result.get("responseText") or UNAVAILABLE_TEXT,
                               {"outcome": result.get("outcome"), "agent": agent, "intake": env,
                                "resolution": resolution, "dispatch": {k: v for k, v in result.items()
                                                                       if k != "downstreamExchanges"},
                                "exchanges": exchanges}, started)
        except A2AClientError as exc:
            return self._reply(sid, raw_text, None, UNAVAILABLE_TEXT,
                               {"outcome": "error", "error": str(exc), "exchanges": exchanges}, started)

    def _reply(self, sid, raw_text, redacted, reply_text, meta, started) -> dict:
        member_msg = self.store.add_message(sid, "member", redacted or "[message withheld]")
        meta["totalLatencyMs"] = round((time.perf_counter() - started) * 1000, 1)
        bot_msg = self.store.add_message(sid, "assistant", reply_text, meta)
        session = self.store.get_session(sid)
        title = None
        if session and session["title"] == "New conversation" and redacted:
            title = redacted if len(redacted) <= 48 else redacted[:45].rstrip() + "\u2026"
        self.store.touch(sid, title)
        return {"member": member_msg, "assistant": bot_msg, "session": self.store.get_session(sid)}
