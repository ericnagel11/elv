/* Member Benefits Assistant - UI (vanilla JS, no build step) */
const $ = (s) => document.querySelector(s);
const state = { config: null, members: [], sessions: [], sessionId: null, messages: [], selectedId: null, busy: false };

const FACTOR_LABELS = {
  intentMatch: "Intent match strength", slotCompletion: "Required-slot completion",
  contextAgreement: "Context agreement", ontologyAlignment: "Ontology alignment",
  evidenceConsistency: "Evidence consistency & ambiguity control",
};
const SOURCE_LABELS = { utterance: "utterance", clarification: "clarification", chatHistory: "chat history",
  profile: "profile", vectorMemory: "vector memory" };
const SUGGESTIONS = [
  ["What’s my copay to see a specialist?", "Asks one clarifying question, then dispatches"],
  ["I need a knee eval", "Then ask the specialist question — grounded from chat history"],
  ["Do I need pre-approval for an MRI?", "Ontology maps “pre-approval” → Prior Authorization"],
  ["Is my Lipitor covered?", "RxNorm synonym → atorvastatin"],
  ["What’s my in-network copay for an allergist?", "Not in plan data → live advocate, no guess"],
  ["Why was my hospital claim adjusted?", "Unsupported intent → live advocate"],
];

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const pct = (v) => (v == null ? "—" : `${Math.round(v * 1000) / 10}%`);
async function api(path, opts = {}) {
  const res = await fetch(path, { headers: { "Content-Type": "application/json" }, ...opts });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || res.statusText);
  return res.json();
}
function when(iso) {
  const d = new Date(iso.endsWith("Z") || iso.includes("+") ? iso : iso + "Z");
  const diff = (Date.now() - d) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)} min ago`;
  if (diff < 86400) return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  return d.toLocaleDateString([], { month: "short", day: "numeric" });
}
const memberById = (id) => state.members.find((m) => m.memberId === id);

/* ---------------- boot ---------------- */
async function boot() {
  [state.config, state.members] = await Promise.all([api("/api/config"), api("/api/members")]);
  $("#memberSelect").innerHTML = state.members.map((m) =>
    `<option value="${m.memberId}">${esc(m.displayName)} · ${esc(m.planType)}</option>`).join("");
  await Promise.all([loadSessions(), loadAgents(), loadQueue()]);
  if (state.sessions.length) await openSession(state.sessions[0].id);
  else renderAll();
  wire();
}

function wire() {
  $("#composer").addEventListener("submit", (e) => { e.preventDefault(); send($("#input").value); });
  $("#input").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send($("#input").value); }
  });
  $("#input").addEventListener("input", autosize);
  $("#newChatBtn").addEventListener("click", newChat);
  $("#memberSelect").addEventListener("change", () => {
    const s = state.sessions.find((x) => x.id === state.sessionId);
    if (!s || s.member_id !== $("#memberSelect").value) newChat();
  });
  $("#traceToggle").addEventListener("click", () => {
    const app = document.querySelector(".app");
    app.classList.toggle("no-trace");
    $("#traceToggle").setAttribute("aria-pressed", String(!app.classList.contains("no-trace")));
  });
  document.querySelectorAll(".tab").forEach((t) => t.addEventListener("click", () => showTab(t.dataset.tab)));
  setInterval(loadAgents, 15000);
}
function autosize() { const t = $("#input"); t.style.height = "auto"; t.style.height = Math.min(t.scrollHeight, 160) + "px"; }
function showTab(name) {
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === name));
  ["confidence", "a2a", "queue"].forEach((n) => $(`#tab-${n}`).classList.toggle("hidden", n !== name));
  if (name === "queue") loadQueue();
}

/* ---------------- data ---------------- */
async function loadSessions() { state.sessions = await api("/api/sessions"); renderSessions(); }
async function loadAgents() {
  try {
    const agents = await api("/api/agents");
    $("#agentList").innerHTML = agents.map((a) => `<li title="${esc(a.url)}"><span class="dot ${a.online ? "on" : ""}"></span>
      ${esc(a.online ? a.card.name : a.key)}<span class="port">:${esc(a.url.split(":").pop())}</span></li>`).join("");
  } catch { /* keep last view */ }
}
async function loadQueue() {
  const q = await api("/api/handoffs");
  $("#tab-queue").innerHTML = q.length ? `<div class="section"><h3>Member Advocate Queue · ${q.length}</h3>` + q.map((h) => `
    <div class="ticket"><div class="ticket-head">${esc(h.ticketId)}<span>${esc(h.status)} · ${when(h.createdAt)}</span></div>
      <p><b>Reason:</b> ${esc(h.reason)}</p>
      <p class="muted">“${esc(h.payload.originalUtterance || "")}”</p>
      <p class="muted">Confidence ${pct(h.payload.confidence)} · ${esc(h.memberToken)}${h.payload.missingOrConflictingSlots?.length ? ` · open: ${esc(h.payload.missingOrConflictingSlots.join(", "))}` : ""}</p>
    </div>`).join("") + "</div>"
    : `<div class="placeholder">No handoffs yet.<br>Interactions that can’t be disambiguated without guessing land here with full context.</div>`;
}
async function openSession(id) {
  state.sessionId = id;
  const s = state.sessions.find((x) => x.id === id);
  if (s) $("#memberSelect").value = s.member_id;
  state.messages = await api(`/api/sessions/${id}/messages`);
  const lastBot = [...state.messages].reverse().find((m) => m.role === "assistant");
  state.selectedId = lastBot ? lastBot.id : null;
  renderAll();
}
function newChat() { state.sessionId = null; state.messages = []; state.selectedId = null; renderAll(); $("#input").focus(); }
async function deleteSession(id, ev) {
  ev.stopPropagation();
  await api(`/api/sessions/${id}`, { method: "DELETE" });
  if (state.sessionId === id) newChat();
  await loadSessions();
}

async function send(text) {
  text = (text || "").trim();
  if (!text || state.busy) return;
  state.busy = true; $("#sendBtn").disabled = true;
  $("#input").value = ""; autosize();
  try {
    if (!state.sessionId) {
      const s = await api("/api/sessions", { method: "POST", body: JSON.stringify({ memberId: $("#memberSelect").value }) });
      state.sessionId = s.id;
    }
    state.messages.push({ id: "tmp", role: "member", text, createdAt: new Date().toISOString() });
    renderMessages(true);
    const res = await api("/api/chat", { method: "POST", body: JSON.stringify({ sessionId: state.sessionId, text }) });
    state.messages = state.messages.filter((m) => m.id !== "tmp").concat([res.member, res.assistant]);
    state.selectedId = res.assistant.id;
    await loadSessions();
    renderAll();
    if (res.assistant.meta?.outcome === "live-agent-transfer") loadQueue();
  } catch (err) {
    state.messages = state.messages.filter((m) => m.id !== "tmp");
    state.messages.push({ id: "err", role: "assistant", text: `Something went wrong: ${err.message}`, createdAt: new Date().toISOString() });
    renderMessages();
  } finally { state.busy = false; $("#sendBtn").disabled = false; $("#input").focus(); }
}

/* ---------------- render: sidebar + chat ---------------- */
function renderAll() { renderSessions(); renderHeader(); renderMessages(); renderTrace(); }
function renderSessions() {
  $("#sessionList").innerHTML = state.sessions.length ? state.sessions.map((s) => {
    const m = memberById(s.member_id);
    return `<div class="session ${s.id === state.sessionId ? "active" : ""}" data-id="${s.id}">
      <div class="session-title">${esc(s.title)}</div>
      <div class="session-meta">${esc(m ? m.displayName.replace(/ \(.*\)/, "") : s.member_id)} · ${when(s.updated_at)} · ${s.message_count} msgs</div>
      <button class="session-del" title="Delete conversation" data-del="${s.id}">×</button></div>`;
  }).join("") : `<div class="empty-history">Your conversations will appear here.</div>`;
  document.querySelectorAll(".session").forEach((el) => el.addEventListener("click", () => openSession(el.dataset.id)));
  document.querySelectorAll(".session-del").forEach((el) => el.addEventListener("click", (e) => deleteSession(el.dataset.del, e)));
}
function renderHeader() {
  const s = state.sessions.find((x) => x.id === state.sessionId);
  $("#chatTitle").textContent = s ? s.title : "New conversation";
  const m = memberById(s ? s.member_id : $("#memberSelect").value);
  const chip = $("#memberChip");
  chip.className = "chip" + (m && m.eligibility !== "active" ? " warn" : "");
  chip.textContent = m ? `${m.planId} · ${m.planType} · ${m.eligibility}` : "";
}
function badgesFor(meta) {
  if (!meta) return "";
  const r = meta.resolution || {};
  const b = [];
  const agent = meta.agent ? `<span class="badge">${esc(meta.agent)}</span>` : "";
  if (meta.outcome === "answered") b.push(`<span class="badge ok">✓ Dispatched · ${pct(r.confidence)}</span>`);
  if (meta.outcome === "clarification") b.push(`<span class="badge info">Clarifying question 1 of ${state.config.maxClarifications} · ${pct(r.confidence)}</span>`);
  if (meta.outcome === "live-agent-transfer") {
    const h = meta.dispatch?.handoff;
    b.push(`<span class="badge warn">→ Live advocate${h ? " · " + esc(h.ticketId) : ""}</span>`);
    if (r.confidence != null) b.push(`<span class="badge">${pct(r.confidence)}</span>`);
  }
  if (meta.intake?.redactionCount) b.push(`<span class="badge">${meta.intake.redactionCount} PHI item(s) redacted</span>`);
  return `<div class="meta-line">${agent}${b.join("")}</div>`;
}
function renderMessages(typing = false) {
  const box = $("#messages");
  if (!state.messages.length && !typing) {
    box.innerHTML = `<div class="welcome">
      <svg viewBox="0 0 32 32" width="48" height="48"><rect rx="10" width="32" height="32" fill="#D8F3EE"/><path d="M9 16.5l4.5 4.5L23 11.5" stroke="#028090" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
      <h2>How can I help with your benefits?</h2>
      <p>Every question is disambiguated before it reaches the Benefits Agent. I’ll ask at most one short question —
      and if I still can’t be certain, I’ll connect you with a live advocate instead of guessing.</p>
      <div class="suggestions">${SUGGESTIONS.map(([t, h]) => `<button class="suggestion" data-q="${esc(t)}">${esc(t)}<small>${esc(h)}</small></button>`).join("")}</div></div>`;
    box.querySelectorAll(".suggestion").forEach((el) => el.addEventListener("click", () => send(el.dataset.q)));
    return;
  }
  box.innerHTML = state.messages.map((m) => {
    const cls = m.meta?.outcome === "live-agent-transfer" ? "transfer" : m.meta?.outcome === "clarification" ? "clarify" : "";
    const sel = m.id === state.selectedId ? "selected" : "";
    return m.role === "member"
      ? `<div class="row member"><div class="time">${when(m.createdAt)}</div><div class="bubble">${esc(m.text)}</div><div class="avatar">You</div></div>`
      : `<div class="row assistant"><div class="avatar">AI</div><div class="bubble ${cls} ${sel}" data-id="${m.id}">${esc(m.text)}${badgesFor(m.meta)}</div><div class="time">${when(m.createdAt)}</div></div>`;
  }).join("") + (typing ? `<div class="row assistant"><div class="avatar">AI</div><div class="bubble"><span class="typing"><i></i><i></i><i></i> Intake → Disambiguation → Dispatch…</span></div></div>` : "");
  box.querySelectorAll(".row.assistant .bubble[data-id]").forEach((el) => el.addEventListener("click", () => {
    state.selectedId = Number(el.dataset.id); renderMessages(); renderTrace();
  }));
  box.scrollTop = box.scrollHeight;
}

/* ---------------- render: trace panel ---------------- */
function renderTrace() {
  const msg = state.messages.find((m) => m.id === state.selectedId);
  const meta = msg?.meta;
  if (!meta) {
    const empty = `<div class="placeholder">Send a message, then select any assistant reply to inspect its confidence score, grounded slots, and A2A exchanges.</div>`;
    $("#tab-confidence").innerHTML = empty; $("#tab-a2a").innerHTML = empty; return;
  }
  $("#tab-confidence").innerHTML = confidenceView(meta);
  $("#tab-a2a").innerHTML = exchangesView(meta);
  document.querySelectorAll(".xchg-head").forEach((h) => h.addEventListener("click", () => h.parentElement.classList.toggle("open")));
}

function outcomeBox(meta) {
  const r = meta.resolution || {};
  const map = {
    answered: ["answered", "✓ Released to Benefits Agent", `Confidence ${pct(r.confidence)} ≥ ${pct(state.config.threshold)} and all required slots grounded`],
    clarification: ["clarification", "? One clarifying question", `Asking for “${r.clarificationSlot}” — projected ${pct(r.trace?.projectedConfidenceIfAnswered)} if answered`],
    "live-agent-transfer": ["live-agent-transfer", "→ Transferred to live advocate",
      meta.dispatch?.handoff?.reasonText ? `Reason: ${meta.dispatch.handoff.reasonText}` : "Cannot disambiguate without guessing"],
  };
  const [cls, title, sub] = map[meta.outcome] || ["other", `Handled by ${meta.agent || "Intake Agent"}`, `Utterance type: ${meta.outcome}`];
  return `<div class="outcome ${cls}"><div>${esc(title)}<small>${esc(sub)}</small></div></div>`;
}

function confidenceView(meta) {
  const r = meta.resolution;
  let html = `<div class="section">${outcomeBox(meta)}</div>`;
  if (!r) {
    const sig = meta.intake?.signals;
    return html + `<div class="section"><h3>Intake</h3><p class="score-note">No disambiguation needed — the Intake Agent handled this turn without calling any domain agent.</p>
      ${sig ? `<pre class="prompt">${esc(JSON.stringify(sig, null, 2))}</pre>` : ""}</div>`;
  }
  const c = r.confidence ?? 0, th = r.threshold;
  const color = c >= th ? "var(--mint)" : c >= 0.6 ? "#E0A43B" : "#D9695B";
  html += `<div class="section"><h3>Composite confidence</h3>
    <div class="gauge"><div class="gauge-fill" style="width:${c * 100}%;background:${color}"></div>
      <div class="gauge-value" style="left:${Math.max(6, Math.min(94, c * 100))}%;color:${color}">${pct(c)}</div>
      <div class="gauge-mark" style="left:${th * 100}%"><span>dispatch ≥ ${pct(th)}</span></div></div>
    ${r.rawConfidence !== r.confidence ? `<p class="score-note">Raw score ${pct(r.rawConfidence)} capped below threshold: ${esc(r.capReasons.join("; "))}.</p>` : ""}
    ${r.penalties?.length ? `<p class="score-note">Penalties: ${esc(r.penalties.join("; "))}.</p>` : ""}</div>`;

  html += `<div class="section"><h3>Confidence factors</h3><table class="kv"><tr><th>Factor</th><th class="num">Weight</th><th class="num">Score</th><th class="num">Points</th></tr>` +
    r.confidenceFactors.map((f) => `<tr><td>${esc(FACTOR_LABELS[f.factor] || f.factor)}<div class="bar"><div style="width:${f.score * 100}%"></div></div></td>
      <td class="num">${Math.round(f.weight * 100)}%</td><td class="num">${f.score.toFixed(2)}</td><td class="num">${(f.contribution * 100).toFixed(1)}</td></tr>`).join("") +
    `<tr class="total"><td>Total</td><td class="num">100%</td><td></td><td class="num">${(r.rawConfidence * 100).toFixed(1)}</td></tr></table></div>`;

  html += `<div class="section"><h3>Resolved intent</h3><table class="kv">
    <tr><td>Intent</td><td class="num">${esc(r.resolvedIntent || "not identified")}</td></tr>
    <tr><td>Canonical concept</td><td class="num">${esc(r.canonicalConcept || "—")}</td></tr>
    <tr><td>Match</td><td class="num">${esc(r.candidates?.[0] ? `${r.candidates[0].matchType}: “${r.candidates[0].matched}”` : "—")}</td></tr></table></div>`;

  if (r.requiredSlots?.length) {
    html += `<div class="section"><h3>Required slots & grounding</h3><table class="kv"><tr><th>Slot</th><th>Value</th><th class="num">Source</th></tr>` +
      r.requiredSlots.map((s) => {
        const ev = r.slotEvidence[s] || {};
        const src = ev.conflict ? `<span class="src missing">conflict</span>` : ev.source ? `<span class="src ${ev.source}">${esc(SOURCE_LABELS[ev.source] || ev.source)}</span>` : `<span class="src missing">missing</span>`;
        const val = ev.conflict ? (ev.conflictValues || []).join(" vs ") : ev.value || "—";
        const detail = (ev.evidence || []).find((e) => e.source === ev.source)?.detail || "";
        return `<tr title="${esc(detail)}"><td>${esc(s)}</td><td>${esc(val)}</td><td class="num">${src}</td></tr>`;
      }).join("") + `</table></div>`;
  }
  const t = r.trace || {};
  const hits = t.memoryHits || [];
  html += `<div class="section"><h3>Grounding trace</h3><ul class="list-plain">
    <li>Ontology version <b>${esc(t.ontologyVersion)}</b> (pinned)</li>
    <li>${t.historyTurnsUsed} chat-history turn(s) · ${hits.length} vector-memory hit(s)</li>
    ${t.referenceBinding ? `<li>Reference “${esc(t.referenceBinding.expression)}” → ${esc(t.referenceBinding.boundTo)}</li>` : ""}
    <li>${t.redactions || 0} PHI/PII redaction(s)</li>
    ${t.clientThresholdIgnored ? `<li>Client-supplied threshold ignored (fixed at ${pct(th)})</li>` : ""}
    <li>LLM advisor: ${t.advisor?.used ? esc(t.advisor.intent || t.advisor.error || "none") : "off (deterministic)"}</li></ul></div>`;
  if (t.zeroShotPrompt) html += `<div class="section"><h3>Zero-shot prompt (audit)</h3><pre class="prompt">${esc(t.zeroShotPrompt)}</pre></div>`;
  return html;
}

function exchangesView(meta) {
  const ex = meta.exchanges || [];
  if (!ex.length) return `<div class="placeholder">No A2A exchanges recorded for this turn.</div>`;
  return `<div class="section"><h3>${ex.length} A2A call(s) · ${meta.totalLatencyMs} ms total</h3>` + ex.map((x, i) => {
    const result = x.response.result || {};
    const st = x.response.error ? "error" : result.status?.state || "—";
    return `<div class="xchg"><div class="xchg-head"><div class="xchg-step">${i + 1}</div>
      <div class="xchg-route"><b>${esc(x.from)}</b> → <b>${esc(x.to)}</b><div>${esc(x.method)} · ${x.latencyMs} ms</div></div>
      <span class="state ${esc(st)}">${esc(st)}</span></div>
      <div class="xchg-body"><div class="lbl">JSON-RPC request</div><pre>${esc(JSON.stringify(x.request, null, 2))}</pre>
      <div class="lbl">JSON-RPC response</div><pre>${esc(JSON.stringify(x.response, trimPrompt, 2))}</pre></div></div>`;
  }).join("") + `</div>`;
}
const trimPrompt = (k, v) => (k === "zeroShotPrompt" ? "(see Confidence tab)" : v);

boot().catch((e) => { $("#messages").innerHTML = `<div class="placeholder">Failed to start: ${esc(e.message)}</div>`; });
