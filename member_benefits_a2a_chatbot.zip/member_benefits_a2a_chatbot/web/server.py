"""Web UI + JSON API (standard library only)."""
from __future__ import annotations

import json
import mimetypes
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import config
from core import data_store
from core.store import Store
from web.orchestrator import Orchestrator


def make_handler(store: Store, orch: Orchestrator):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_a):
            pass

        def _json(self, code: int, body):
            raw = json.dumps(body).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(raw)

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length", 0))
            try:
                return json.loads(self.rfile.read(n) or b"{}")
            except json.JSONDecodeError:
                return {}

        def do_GET(self):
            path = self.path.split("?")[0]
            if path == "/api/members":
                return self._json(200, [{"memberId": m["memberId"], "displayName": m["displayName"],
                                         "planId": m["planId"], "planType": m["planType"],
                                         "eligibility": m["eligibility"]} for m in data_store.members()])
            if path == "/api/sessions":
                return self._json(200, store.list_sessions())
            m = re.fullmatch(r"/api/sessions/([\w-]+)/messages", path)
            if m:
                return self._json(200, store.messages(m.group(1)))
            if path == "/api/agents":
                return self._json(200, orch.agent_cards())
            if path == "/api/handoffs":
                return self._json(200, store.handoffs())
            if path == "/api/config":
                return self._json(200, {"threshold": config.CONFIDENCE_THRESHOLD,
                                        "maxClarifications": config.MAX_CLARIFICATIONS,
                                        "weights": config.CONFIDENCE_WEIGHTS,
                                        "ontologyVersion": data_store.ontology()["version"]})
            self._static(path)

        def do_POST(self):
            path = self.path.split("?")[0]
            body = self._body()
            if path == "/api/sessions":
                if not data_store.member_by_id(body.get("memberId", "")):
                    return self._json(400, {"error": "unknown member"})
                return self._json(201, store.create_session(body["memberId"]))
            if path == "/api/chat":
                text = (body.get("text") or "").strip()
                if not text or len(text) > 1000:
                    return self._json(400, {"error": "text must be 1-1000 characters"})
                try:
                    return self._json(200, orch.handle_turn(body.get("sessionId", ""), text))
                except KeyError:
                    return self._json(404, {"error": "session not found"})
            self._json(404, {"error": "not found"})

        def do_DELETE(self):
            m = re.fullmatch(r"/api/sessions/([\w-]+)", self.path.split("?")[0])
            if m:
                store.delete_session(m.group(1))
                return self._json(200, {"deleted": m.group(1)})
            self._json(404, {"error": "not found"})

        def _static(self, path: str):
            rel = "index.html" if path in ("/", "") else path.lstrip("/")
            target = (config.STATIC_DIR / rel).resolve()
            if not str(target).startswith(str(config.STATIC_DIR.resolve())) or not target.is_file():
                return self._json(404, {"error": "not found"})
            raw = target.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", mimetypes.guess_type(str(target))[0] or "application/octet-stream")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

    return Handler


def start_ui(store: Store, orch: Orchestrator, host: str, port: int) -> ThreadingHTTPServer:
    server = ThreadingHTTPServer((host, port), make_handler(store, orch))
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, name="web-ui", daemon=True).start()
    return server
