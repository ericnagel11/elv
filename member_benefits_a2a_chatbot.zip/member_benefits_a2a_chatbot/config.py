"""Central configuration for the Member Utterance Disambiguation chatbot.

Governance values (threshold, clarification ceiling, factor weights) are fixed here
and are NOT overridable by A2A clients, per the white paper (Sections 8.4, 10, 11).
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
STATIC_DIR = BASE_DIR / "web" / "static"
DB_PATH = Path(os.getenv("CHATBOT_DB_PATH", str(DATA_DIR / "chatbot.db")))

HOST = os.getenv("APP_HOST", "127.0.0.1")
UI_PORT = int(os.getenv("UI_PORT", "8000"))
INTAKE_PORT = int(os.getenv("INTAKE_PORT", "8101"))
DISAMBIGUATION_PORT = int(os.getenv("DISAMBIGUATION_PORT", "8102"))
DISPATCH_PORT = int(os.getenv("DISPATCH_PORT", "8103"))
BENEFITS_PORT = int(os.getenv("BENEFITS_PORT", "8104"))


def agent_url(port: int) -> str:
    return f"http://{HOST}:{port}"


# ---- Governance (white paper Sections 8.4, 8.4.1, 8.5, 10) -------------------
CONFIDENCE_THRESHOLD = 0.80          # dispatch to Benefits Agent at >= 0.80
MAX_CLARIFICATIONS = 1               # one clarifying question, never two
CHAT_HISTORY_TURNS = 6               # last N member turns used for grounding
VECTOR_TOP_K = 5
VECTOR_MIN_RELEVANCE = 0.20

# Confidence factor weights - must total 1.00 (white paper table 8.4.1)
CONFIDENCE_WEIGHTS = {
    "intentMatch": 0.30,
    "slotCompletion": 0.25,
    "contextAgreement": 0.20,
    "ontologyAlignment": 0.15,
    "evidenceConsistency": 0.10,
}
assert abs(sum(CONFIDENCE_WEIGHTS.values()) - 1.0) < 1e-9, "weights must total 100%"

# Reliability of each grounding source when it supplies a slot value
SOURCE_STRENGTH = {
    "utterance": 1.00,
    "clarification": 1.00,
    "profile": 1.00,
    "chatHistory": 0.95,
    "vectorMemory": 0.85,
}

# Minimum intent-match score before an intent is considered identified at all
INTENT_FLOOR = 0.45
# Second-best / best ratio at or above which two intents are "competing"
COMPETING_INTENT_RATIO = 0.90

# ---- Optional LLM advisor (off by default; it can only confirm or LOWER confidence)
USE_LLM = os.getenv("USE_LLM", "0") == "1"
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT", "")
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY", "")
AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT", "")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
