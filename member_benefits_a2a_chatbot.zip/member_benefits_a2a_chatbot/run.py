"""Start all A2A agents and the web UI.

    python run.py            -> http://127.0.0.1:8000
"""
import signal
import sys
import threading
import webbrowser

import config
from agents.benefits_agent import BenefitsAgent
from agents.disambiguation_agent import DisambiguationAgent
from agents.dispatch_agent import DispatchAgent
from agents.intake_agent import IntakeAgent
from core.store import Store
from web.orchestrator import Orchestrator
from web.server import start_ui


def build(store: Store, host: str = config.HOST, ports: dict | None = None):
    ports = ports or {"intake": config.INTAKE_PORT, "disambiguation": config.DISAMBIGUATION_PORT,
                      "dispatch": config.DISPATCH_PORT, "benefits": config.BENEFITS_PORT}
    benefits = BenefitsAgent(host, ports["benefits"])
    benefits.start()
    dispatch = DispatchAgent(host, ports["dispatch"], benefits.url, store)
    dispatch.start()
    disamb = DisambiguationAgent(host, ports["disambiguation"])
    disamb.start()
    intake = IntakeAgent(host, ports["intake"])
    intake.start()
    orch = Orchestrator(store, intake.url, disamb.url, dispatch.url, benefits.url)
    return orch, [intake, disamb, dispatch, benefits]


def main():
    store = Store()
    orch, agents = build(store)
    ui = start_ui(store, orch, config.HOST, config.UI_PORT)
    url = f"http://{config.HOST}:{config.UI_PORT}"
    print("\nMember Benefits Assistant  \u2014  disambiguate before dispatch")
    for a in agents:
        print(f"  A2A  {a.name:<22} {a.url}/.well-known/agent-card.json")
    print(f"\n  UI   {url}\n\n  Press Ctrl+C to stop.\n")
    if "--no-browser" not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    stop = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    while not stop.is_set():
        stop.wait(0.5)
    ui.shutdown()
    for a in agents:
        a.stop()


if __name__ == "__main__":
    main()
