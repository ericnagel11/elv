"""Optional Azure OpenAI advisor (disabled by default: USE_LLM=0).

Safety contract: the model may only name an intent that already exists in the
deterministic candidate list. Anything else is discarded. Agreement leaves the
score unchanged; disagreement LOWERS evidence consistency. The model can never
raise confidence or supply slot values, so it cannot cause a hallucinated dispatch.
"""
from __future__ import annotations

import json
import urllib.request

import config


def enabled() -> bool:
    return bool(config.USE_LLM and config.AZURE_OPENAI_ENDPOINT and config.AZURE_OPENAI_API_KEY
                and config.AZURE_OPENAI_DEPLOYMENT)


def advise(prompt: str, allowed_intents: list[str]) -> dict:
    if not enabled():
        return {"used": False}
    url = (f"{config.AZURE_OPENAI_ENDPOINT.rstrip('/')}/openai/deployments/{config.AZURE_OPENAI_DEPLOYMENT}"
           f"/chat/completions?api-version={config.AZURE_OPENAI_API_VERSION}")
    body = {"messages": [{"role": "system", "content": prompt},
                         {"role": "user", "content": "Return the JSON now."}],
            "temperature": 0, "max_tokens": 120, "response_format": {"type": "json_object"}}
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "api-key": config.AZURE_OPENAI_API_KEY})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            content = json.loads(resp.read())["choices"][0]["message"]["content"]
        intent = json.loads(content).get("intent")
    except Exception as exc:  # advisor failure never blocks or alters the deterministic path
        return {"used": True, "error": str(exc), "intent": None, "valid": False}
    return {"used": True, "intent": intent, "valid": intent in allowed_intents}
