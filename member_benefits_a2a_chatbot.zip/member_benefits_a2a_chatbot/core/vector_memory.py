"""PHI-safe, member-scoped vector memory with top-k nearest-neighbor retrieval.

Dependency-free bag-of-words cosine similarity is used so the sample runs anywhere.
In production, replace `retrieve` with an embedding index (e.g., Azure AI Search)
filtered by the member token - the contract (entries + relevance) stays the same.
"""
from __future__ import annotations

import math
import re
from collections import Counter

import config
from core import data_store

_STOP = set("a an the i my me to for of and or is are was be it this that on in at do does can what how much "
            "with about will would am you your have has had need see get".split())


def _vec(text: str) -> Counter:
    return Counter(t for t in re.findall(r"[a-z0-9-]+", text.lower()) if t not in _STOP)


def _cosine(a: Counter, b: Counter) -> float:
    if not a or not b:
        return 0.0
    dot = sum(a[k] * b[k] for k in a if k in b)
    return dot / (math.sqrt(sum(v * v for v in a.values())) * math.sqrt(sum(v * v for v in b.values())))


def retrieve(member_token: str, query: str, concept_id: str | None = None,
             top_k: int = config.VECTOR_TOP_K, min_relevance: float = config.VECTOR_MIN_RELEVANCE) -> list[dict]:
    """Return memory hits strictly scoped to this member, best first."""
    qv = _vec(query)
    hits = []
    for entry in data_store.member_memory(member_token):
        score = _cosine(qv, _vec(entry["text"]))
        if concept_id and concept_id in entry.get("concepts", []):
            score += 0.35
        score = round(min(score, 1.0), 3)
        if score >= min_relevance:
            hits.append({"id": entry["id"], "date": entry["date"], "relevance": score,
                         "text": entry["text"], "slots": entry.get("slots", {})})
    hits.sort(key=lambda h: h["relevance"], reverse=True)
    return hits[:top_k]
