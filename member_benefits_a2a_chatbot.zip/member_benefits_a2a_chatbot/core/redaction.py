"""PHI/PII stripping and tokenization (white paper Sections 4, 8.2 - privacy & audit).

Runs before any text is embedded, cached, logged, or sent to another agent.
"""
import re

_PATTERNS = [
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")),
    ("PHONE", re.compile(r"(?<!\d)(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}(?!\d)")),
    ("DOB", re.compile(r"\b(?:dob|date of birth|born on|birthday)\s*(?:is|:)?\s*\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b", re.I)),
    ("MEMBER_ID", re.compile(r"\b(?:member\s*(?:id|number|#)\s*(?:is|:)?\s*)[A-Z0-9-]{5,}\b", re.I)),
    ("CARD_NUMBER", re.compile(r"\b(?:\d[ -]?){13,16}\b")),
]


def redact(text: str) -> tuple[str, list[dict]]:
    """Return (redacted_text, redactions). Each redaction records type and token only."""
    redactions: list[dict] = []
    counters: dict[str, int] = {}
    out = text
    for kind, pattern in _PATTERNS:
        def _sub(_m, kind=kind):
            counters[kind] = counters.get(kind, 0) + 1
            token = f"[{kind}_TOKEN_{counters[kind]}]"
            redactions.append({"type": kind, "token": token})
            return token
        out = pattern.sub(_sub, out)
    return out, redactions
