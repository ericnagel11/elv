"""Deterministic utterance-signal extraction (white paper Section 6).

Six signals are computed before any model sees the text:
normalize, resolve reference, detect negation, anchor time, extract slots, score ambiguity.
"""
from __future__ import annotations

import datetime as _dt
import re

_EXPANSIONS = [
    (r"\bwhat's\b", "what is"), (r"\bwhats\b", "what is"), (r"\bhow's\b", "how is"),
    (r"\bi'm\b", "i am"), (r"\bim\b", "i am"), (r"\bcan't\b", "cannot"), (r"\bwon't\b", "will not"),
    (r"\bco[\s-]?pays?\b", "copay"), (r"\bdr\.?(?=\s)", "doctor"), (r"\bappt\b", "appointment"),
    (r"\beval\b", "evaluation"), (r"\bmeds\b", "medication"), (r"\bmed\b", "medication"),
    (r"\bdeductable\b", "deductible"), (r"\bspecalist\b", "specialist"), (r"\bperscription\b", "prescription"),
]

_NEGATION = re.compile(
    r"\b(?:not (?:the|a|an|my|for|about)|no|isn't|isnt|except(?: for)?|excluding|other than|"
    r"instead of|rather than|don't mean|dont mean|don't want|dont want)\s+((?:[\w-]+\s*){1,3})")
_HYPOTHETICAL = re.compile(r"\b(?:what if|if i were|suppose|hypothetically|in case)\b")
_PRONOUN = re.compile(r"\b(?:that one|this one|that|it|this|same one|the same|those|them)\b")
_QUESTION_START = re.compile(
    r"^(?:what|how|is|are|do|does|did|can|could|will|would|am|which|when|where|why|should|tell me|"
    r"i want to know|i need to know|check|show me|find)\b")
_GREETING = re.compile(r"^(?:hi|hello|hey|good (?:morning|afternoon|evening)|thanks|thank you|ok|okay)\b")
_HELP = re.compile(r"^(?:help|what can you do|how does this work|menu)\b")


def normalize(text: str) -> str:
    t = text.lower().replace("\u2019", "'").replace("\u2018", "'")
    for pattern, repl in _EXPANSIONS:
        t = re.sub(pattern, repl, t)
    t = re.sub(r"\[[a-z_]+_token_\d+\]", " ", t)          # drop redaction tokens
    t = re.sub(r"[^\w\s'-]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def find_phrase(phrase: str, text: str) -> tuple[int, int] | None:
    m = re.search(r"(?<![a-z0-9])" + re.escape(phrase) + r"(?![a-z0-9])", text)
    return (m.start(), m.end()) if m else None


def detect_negation(norm: str) -> list[dict]:
    return [{"cue": m.group(0).split()[0], "span": m.group(1).strip(), "start": m.start(1), "end": m.end(1)}
            for m in _NEGATION.finditer(norm)]


def in_negated(span: tuple[int, int], negations: list[dict]) -> bool:
    return any(span[0] >= n["start"] and span[1] <= n["end"] + 1 for n in negations)


def anchor_time(norm: str, today: _dt.date | None = None) -> dict | None:
    today = today or _dt.date.today()
    if find_phrase("last month", norm):
        first = today.replace(day=1) - _dt.timedelta(days=1)
        return {"expression": "last month", "resolved": first.strftime("%Y-%m"), "planYear": str(first.year)}
    for phrase, delta in (("next year", 1), ("last year", -1), ("this year", 0), ("current year", 0)):
        if find_phrase(phrase, norm):
            return {"expression": phrase, "resolved": str(today.year + delta), "planYear": str(today.year + delta)}
    m = re.search(r"\b(20\d{2})\b", norm)
    if m:
        return {"expression": m.group(1), "resolved": m.group(1), "planYear": m.group(1)}
    return None


def extract_slot_values(norm: str, ontology: dict, negations: list[dict] | None = None) -> dict:
    """Map candidate entities to slot values. Returns {slot: {"values": [...], "phrases": [...]}}."""
    negations = negations if negations is not None else detect_negation(norm)
    found: dict[str, dict] = {}
    for slot, spec in ontology["slots"].items():
        for canonical, synonyms in (spec.get("values") or {}).items():
            for syn in sorted(synonyms, key=len, reverse=True):
                span = find_phrase(syn, norm)
                if span and not in_negated(span, negations):
                    entry = found.setdefault(slot, {"values": [], "phrases": []})
                    if canonical not in entry["values"]:
                        entry["values"].append(canonical)
                        entry["phrases"].append(syn)
                    break
    anchor = anchor_time(norm)
    if anchor:
        found["planYear"] = {"values": [anchor["planYear"]], "phrases": [anchor["expression"]]}
    return found


def match_concepts(norm: str, ontology: dict, negations: list[dict] | None = None,
                   slot_values: dict | None = None) -> list[dict]:
    """Score every canonical concept against the normalized utterance, best first."""
    negations = negations if negations is not None else detect_negation(norm)
    slot_values = slot_values if slot_values is not None else extract_slot_values(norm, ontology, negations)
    cost_words = ("copay", "cost", "pay", "price", "how much", "charge", "covered", "coverage")
    results = []
    for c in ontology["concepts"]:
        best = None
        for syn in sorted(c["synonyms"], key=len, reverse=True):
            span = find_phrase(syn, norm)
            if span and not in_negated(span, negations):
                best = {"score": 1.0, "alignment": 1.0, "matchType": "synonym", "matched": syn}
                break
        if best is None:
            implied_slot = {"specialist_copay": "providerType", "rx_coverage": "drugName"}.get(c["id"])
            if implied_slot and implied_slot in slot_values and any(find_phrase(w, norm) for w in cost_words):
                best = {"score": 0.90, "alignment": 0.85, "matchType": "slot-implied",
                        "matched": slot_values[implied_slot]["phrases"][0]}
        if best is None:
            hits = [k for k in c.get("keywords", []) if (sp := find_phrase(k, norm)) and not in_negated(sp, negations)]
            if hits:
                best = {"score": min(0.60, 0.25 + 0.10 * len(hits)), "alignment": 0.60 if len(hits) > 1 else 0.40,
                        "matchType": "keyword", "matched": ", ".join(hits)}
        if best:
            results.append({"conceptId": c["id"], "canonical": c["canonical"], "intent": c["intent"],
                            "codeSystem": c["codeSystem"], **best})
    results.sort(key=lambda r: r["score"], reverse=True)
    return results


def find_references(norm: str) -> list[str]:
    return [m.group(0) for m in _PRONOUN.finditer(norm)]


def classify(raw: str, norm: str, concepts: list[dict], slot_values: dict) -> str:
    """Classify the utterance for intake routing: greeting | help | context | request."""
    strong_concept = any(c["score"] >= 0.45 for c in concepts)
    is_question = raw.strip().endswith("?") or bool(_QUESTION_START.match(norm))
    if _HELP.match(norm) and not strong_concept:
        return "help"
    if _GREETING.match(norm) and not strong_concept and len(norm.split()) <= 5:
        return "greeting"
    if not strong_concept and not is_question and slot_values:
        return "context"
    return "request"


def is_hypothetical(norm: str) -> bool:
    return bool(_HYPOTHETICAL.search(norm))
