"""Zero-shot prompt assembly from six fixed blocks (white paper Section 7).

The structure is stable across calls; only grounded content varies. The assembled
prompt is recorded in the trace for audit. It is sent to a model only when the
optional LLM advisor is enabled - and even then the model can only confirm or
lower confidence, never supply slot values.
"""
from __future__ import annotations

import json


def build(analysis: dict, concepts: list[dict], member_context: dict, memory_hits: list[dict],
          chat_history: list[dict]) -> str:
    role = ("ROLE & TASK\nYou resolve a member utterance to exactly one canonical intent from the ONTOLOGY "
            "block, or return exactly one clarifying question. Never invent intents, slot values, member facts, "
            "or benefit amounts. If the utterance cannot be resolved from the evidence below, return intent null.")
    utterance = "UTTERANCE ANALYSIS\n" + json.dumps(analysis, indent=1)
    ontology = "ONTOLOGY\n" + json.dumps([{"canonical": c["canonical"], "intent": c["intent"],
                                           "synonyms": c["synonyms"][:5], "requiredSlots": c["requiredSlots"],
                                           "clarifyOn": c.get("clarifyOn")} for c in concepts], indent=1)
    member = "MEMBER CONTEXT (PHI-stripped, tokenized)\n" + json.dumps(
        {"profile": {k: member_context.get(k) for k in ("memberToken", "planId", "planType", "eligibility")},
         "vectorMemory": [{"text": h["text"], "relevance": h["relevance"]} for h in memory_hits]}, indent=1)
    history = "CHAT HISTORY\n" + ("\n".join(f"{t['role']}: {t['text']}" for t in chat_history) or "(no active session)")
    contract = ("OUTPUT CONTRACT\nReturn strict JSON: {\"intent\": <one intent from ONTOLOGY or null>, "
                "\"reason\": <short string>}. clarification is a single string or null - never a list.")
    return "\n\n".join([role, utterance, ontology, member, history, contract])
