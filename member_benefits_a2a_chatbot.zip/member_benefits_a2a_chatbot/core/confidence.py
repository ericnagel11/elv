"""Composite confidence scoring (white paper Sections 8.4 and 8.4.1).

confidence = sum(weight_i * factor_i), each factor in [0, 1], weights total 100%:
  Intent match strength ........................ 30%
  Required-slot completion ..................... 25%
  Context agreement ............................ 20%
  Ontology alignment ........................... 15%
  Evidence consistency and ambiguity control ... 10%

The score is computed by application code from traced evidence - it is never a
model's self-reported certainty. Missing required slots, unresolved conflicts, or
competing intents cap the score just below the threshold so the rule
"dispatch only when confidence >= 0.80" is always consistent with the gate.
"""
from __future__ import annotations

import config


def _intent_factor(candidates: list[dict]) -> float:
    if not candidates:
        return 0.0
    top = candidates[0]["score"]
    second = candidates[1]["score"] if len(candidates) > 1 else 0.0
    separation = 1.0 - (second / top) if top else 0.0
    return top * (0.6 + 0.4 * separation)


def _slot_agreement(slot: dict) -> float:
    """1.0 when all evidence agrees; each disagreeing lower-precedence source costs 0.1."""
    if slot.get("value") is None:
        return 0.0
    disagreements = sum(1 for e in slot["evidence"] if e["value"] != slot["value"])
    return max(0.6, 1.0 - 0.1 * disagreements)


def compute(candidates: list[dict], required: list[str], slots: dict, flags: dict) -> dict:
    w = config.CONFIDENCE_WEIGHTS
    filled = [s for s in required if slots.get(s, {}).get("value") is not None]
    missing = [s for s in required if s not in filled]
    conflicts = [s for s in required if slots.get(s, {}).get("conflict")]

    per_slot = []
    for s in required:
        st = slots.get(s, {})
        if st.get("value") is None:
            per_slot.append(0.0)
        else:
            per_slot.append(config.SOURCE_STRENGTH.get(st["source"], 0.8) * _slot_agreement(st))

    evidence = 1.0
    penalties = []
    for s in conflicts:
        evidence -= 0.5
        penalties.append(f"conflicting values for {s}")
    if flags.get("unresolvedReference"):
        evidence -= 0.4
        penalties.append("reference could not be bound to prior context")
    if flags.get("competingIntents"):
        evidence -= 0.3
        penalties.append("competing intents")
    if flags.get("llmDisagreement"):
        evidence -= 0.2
        penalties.append("advisory model disagreed with deterministic intent")
    if flags.get("hypothetical"):
        evidence -= 0.1
        penalties.append("hypothetical phrasing")

    factors = {
        "intentMatch": _intent_factor(candidates),
        "slotCompletion": (len(filled) / len(required)) if required else 0.0,
        "contextAgreement": (sum(per_slot) / len(per_slot)) if per_slot else 0.0,
        "ontologyAlignment": candidates[0]["alignment"] if candidates else 0.0,
        "evidenceConsistency": max(0.0, min(1.0, evidence)),
    }
    breakdown = [{"factor": k, "weight": w[k], "score": round(v, 3), "contribution": round(w[k] * v, 4)}
                 for k, v in factors.items()]
    raw = round(sum(b["contribution"] for b in breakdown), 3)

    cap_reasons = []
    if missing:
        cap_reasons.append(f"missing required slot(s): {', '.join(missing)}")
    if conflicts:
        cap_reasons.append(f"unresolved conflict: {', '.join(conflicts)}")
    if flags.get("competingIntents"):
        cap_reasons.append("competing intents")
    if flags.get("intentNotIdentified"):
        cap_reasons.append("no canonical intent identified")
    final = min(raw, round(config.CONFIDENCE_THRESHOLD - 0.01, 2)) if cap_reasons else raw

    return {"confidence": final, "rawConfidence": raw, "threshold": config.CONFIDENCE_THRESHOLD,
            "factors": breakdown, "capReasons": cap_reasons, "penalties": penalties,
            "missingSlots": missing, "conflictingSlots": conflicts}


def project_with(candidates: list[dict], required: list[str], slots: dict, flags: dict, slot_name: str) -> float:
    """Confidence if `slot_name` were answered by one clarifying question."""
    import copy
    trial = copy.deepcopy(slots)
    trial[slot_name] = {"value": "__clarified__", "source": "clarification", "evidence": [], "conflict": False}
    return compute(candidates, required, trial, flags)["confidence"]
