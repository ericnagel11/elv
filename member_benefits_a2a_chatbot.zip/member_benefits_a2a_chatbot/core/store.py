"""SQLite persistence: chat sessions, chat history, and the live-advocate handoff queue."""
from __future__ import annotations

import datetime as _dt
import json
import random
import sqlite3
import string
import threading
import uuid

import config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY, member_id TEXT NOT NULL, title TEXT NOT NULL,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, pending_json TEXT);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL, role TEXT NOT NULL,
  text TEXT NOT NULL, meta_json TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS handoffs (
  ticket_id TEXT PRIMARY KEY, session_id TEXT, member_token TEXT, reason TEXT,
  payload_json TEXT, status TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_messages_session ON messages(session_id, id);
"""


def _now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")


class Store:
    def __init__(self, path=None):
        self.path = str(path or config.DB_PATH)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(self.path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.executescript(_SCHEMA)
        self._db.commit()

    # -- sessions
    def create_session(self, member_id: str) -> dict:
        sid, now = str(uuid.uuid4()), _now()
        with self._lock:
            self._db.execute("INSERT INTO sessions VALUES (?,?,?,?,?,NULL)", (sid, member_id, "New conversation", now, now))
            self._db.commit()
        return self.get_session(sid)

    def get_session(self, sid: str) -> dict | None:
        with self._lock:
            row = self._db.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
        if not row:
            return None
        d = dict(row)
        d["pending"] = json.loads(d.pop("pending_json") or "null")
        return d

    def list_sessions(self) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                "SELECT s.*, (SELECT COUNT(*) FROM messages m WHERE m.session_id=s.id) AS message_count "
                "FROM sessions s ORDER BY updated_at DESC").fetchall()
        return [{k: r[k] for k in r.keys() if k != "pending_json"} for r in rows]

    def delete_session(self, sid: str) -> None:
        with self._lock:
            self._db.execute("DELETE FROM messages WHERE session_id=?", (sid,))
            self._db.execute("DELETE FROM sessions WHERE id=?", (sid,))
            self._db.commit()

    def set_pending(self, sid: str, pending: dict | None) -> None:
        with self._lock:
            self._db.execute("UPDATE sessions SET pending_json=? WHERE id=?",
                             (json.dumps(pending) if pending else None, sid))
            self._db.commit()

    def touch(self, sid: str, title: str | None = None) -> None:
        with self._lock:
            if title:
                self._db.execute("UPDATE sessions SET updated_at=?, title=? WHERE id=?", (_now(), title, sid))
            else:
                self._db.execute("UPDATE sessions SET updated_at=? WHERE id=?", (_now(), sid))
            self._db.commit()

    # -- messages
    def add_message(self, sid: str, role: str, text: str, meta: dict | None = None) -> dict:
        now = _now()
        with self._lock:
            cur = self._db.execute("INSERT INTO messages (session_id, role, text, meta_json, created_at) VALUES (?,?,?,?,?)",
                                   (sid, role, text, json.dumps(meta) if meta else None, now))
            self._db.commit()
            mid = cur.lastrowid
        return {"id": mid, "sessionId": sid, "role": role, "text": text, "meta": meta, "createdAt": now}

    def messages(self, sid: str) -> list[dict]:
        with self._lock:
            rows = self._db.execute("SELECT * FROM messages WHERE session_id=? ORDER BY id", (sid,)).fetchall()
        return [{"id": r["id"], "sessionId": sid, "role": r["role"], "text": r["text"],
                 "meta": json.loads(r["meta_json"]) if r["meta_json"] else None, "createdAt": r["created_at"]}
                for r in rows]

    # -- live-advocate handoffs
    def create_handoff(self, session_id: str, member_token: str, reason: str, payload: dict) -> dict:
        ticket = "LA-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
        now = _now()
        with self._lock:
            self._db.execute("INSERT INTO handoffs VALUES (?,?,?,?,?,?,?)",
                             (ticket, session_id, member_token, reason, json.dumps(payload), "queued", now))
            self._db.commit()
        return {"ticketId": ticket, "status": "queued", "queue": "Member Advocate Queue",
                "reason": reason, "createdAt": now}

    def handoffs(self) -> list[dict]:
        with self._lock:
            rows = self._db.execute("SELECT * FROM handoffs ORDER BY created_at DESC").fetchall()
        return [{"ticketId": r["ticket_id"], "sessionId": r["session_id"], "memberToken": r["member_token"],
                 "reason": r["reason"], "status": r["status"], "createdAt": r["created_at"],
                 "payload": json.loads(r["payload_json"] or "{}")} for r in rows]
