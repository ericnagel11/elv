"""Loads versioned configuration (ontology) and sample reference data.

The ontology is externalized configuration: it is version-pinned at load and can be
hot-reloaded on publish (white paper Section 5.2) without a code deployment.
"""
import json
import threading
from pathlib import Path

import config

_lock = threading.Lock()
_cache: dict[str, tuple[float, dict]] = {}


def _load(name: str) -> dict:
    path: Path = config.DATA_DIR / name
    mtime = path.stat().st_mtime
    with _lock:
        cached = _cache.get(name)
        if cached and cached[0] == mtime:
            return cached[1]
        data = json.loads(path.read_text(encoding="utf-8"))
        _cache[name] = (mtime, data)
        return data


def ontology() -> dict:
    return _load("ontology.json")


def members() -> list[dict]:
    return _load("members.json")["members"]


def member_by_id(member_id: str) -> dict | None:
    return next((m for m in members() if m["memberId"] == member_id), None)


def member_by_token(token: str) -> dict | None:
    return next((m for m in members() if m["memberToken"] == token), None)


def member_memory(token: str) -> list[dict]:
    return _load("member_memory.json")["memory"].get(token, [])


def benefit_plans() -> dict:
    return _load("benefit_plans.json")["plans"]
