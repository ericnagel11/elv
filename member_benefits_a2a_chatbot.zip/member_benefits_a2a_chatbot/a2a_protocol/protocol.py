"""Minimal, dependency-free implementation of the Agent2Agent (A2A) protocol.

Implements the A2A v0.3.0 JSON-RPC 2.0 binding:
  * Agent discovery:  GET /.well-known/agent-card.json  (legacy /.well-known/agent.json)
  * Methods:          message/send, tasks/get, tasks/cancel
  * Data model:       Message, Part (kind: text | data), Task, TaskStatus, Artifact
  * Task states:      submitted, working, input-required, completed, canceled,
                      failed, rejected, auth-required, unknown

The wire format is isolated in this module so it can be swapped for the official
`a2a-sdk` package (or a newer protocol version) without touching agent logic.
"""
from __future__ import annotations

import copy
import datetime as _dt
import json
import threading
import time
import urllib.error
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable

PROTOCOL_VERSION = "0.3.0"


class TaskState:
    SUBMITTED = "submitted"
    WORKING = "working"
    INPUT_REQUIRED = "input-required"
    COMPLETED = "completed"
    CANCELED = "canceled"
    FAILED = "failed"
    REJECTED = "rejected"
    AUTH_REQUIRED = "auth-required"
    UNKNOWN = "unknown"


TERMINAL_STATES = {TaskState.COMPLETED, TaskState.CANCELED, TaskState.FAILED, TaskState.REJECTED}

# JSON-RPC / A2A error codes
PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603
TASK_NOT_FOUND = -32001
TASK_NOT_CANCELABLE = -32002
UNSUPPORTED_OPERATION = -32004


def now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="milliseconds")


def new_id() -> str:
    return str(uuid.uuid4())


# ---- Part / Message helpers ------------------------------------------------------
def text_part(text: str) -> dict:
    return {"kind": "text", "text": text}


def data_part(data: dict) -> dict:
    return {"kind": "data", "data": data}


def make_message(role: str, parts: list[dict], context_id: str | None = None,
                 task_id: str | None = None, metadata: dict | None = None) -> dict:
    msg = {"kind": "message", "messageId": new_id(), "role": role, "parts": parts}
    if context_id:
        msg["contextId"] = context_id
    if task_id:
        msg["taskId"] = task_id
    if metadata:
        msg["metadata"] = metadata
    return msg


def get_text(obj: dict | None) -> str:
    if not obj:
        return ""
    return "\n".join(p.get("text", "") for p in obj.get("parts", []) if p.get("kind") == "text").strip()


def get_data(obj: dict | None) -> dict:
    merged: dict = {}
    if not obj:
        return merged
    for p in obj.get("parts", []):
        if p.get("kind") == "data" and isinstance(p.get("data"), dict):
            merged.update(p["data"])
    return merged


def artifact_data(task: dict, name: str) -> dict:
    for art in task.get("artifacts", []) or []:
        if art.get("name") == name:
            return get_data(art)
    return {}


class A2AError(Exception):
    def __init__(self, code: int, message: str, data: Any = None):
        super().__init__(message)
        self.code, self.message, self.data = code, message, data

    def to_dict(self) -> dict:
        err = {"code": self.code, "message": self.message}
        if self.data is not None:
            err["data"] = self.data
        return err


# ---- Server ----------------------------------------------------------------------
class A2AAgent:
    """Base class for an A2A server agent. Subclasses implement `handle_message`."""

    name = "A2A Agent"
    description = ""
    version = "1.0.0"
    skills: list[dict] = []

    def __init__(self, host: str, port: int):
        self.host, self.port = host, port
        self.url = f"http://{host}:{port}"
        self._tasks: dict[str, dict] = {}
        self._lock = threading.RLock()
        self._server: ThreadingHTTPServer | None = None

    # -- Agent Card
    def agent_card(self) -> dict:
        return {
            "protocolVersion": PROTOCOL_VERSION,
            "name": self.name,
            "description": self.description,
            "url": self.url + "/",
            "preferredTransport": "JSONRPC",
            "version": self.version,
            "provider": {"organization": "Member Services (sample)", "url": self.url},
            "capabilities": {"streaming": False, "pushNotifications": False,
                             "stateTransitionHistory": True},
            "defaultInputModes": ["text/plain", "application/json"],
            "defaultOutputModes": ["text/plain", "application/json"],
            "skills": self.skills,
        }

    # -- Subclass hook
    def handle_message(self, message: dict, task: dict, is_continuation: bool) -> None:  # pragma: no cover
        raise NotImplementedError

    # -- Task mutation helpers (for subclasses)
    def set_status(self, task: dict, state: str, text: str | None = None,
                   data: dict | None = None) -> None:
        status = {"state": state, "timestamp": now_iso()}
        if text is not None or data is not None:
            parts = []
            if text is not None:
                parts.append(text_part(text))
            if data is not None:
                parts.append(data_part(data))
            status["message"] = make_message("agent", parts, task["contextId"], task["id"])
            task["history"].append(status["message"])
        task["status"] = status
        task.setdefault("metadata", {}).setdefault("stateTransitions", []).append(
            {"state": state, "timestamp": status["timestamp"]})

    def add_artifact(self, task: dict, name: str, data: dict | None = None,
                     text: str | None = None, description: str = "") -> None:
        parts = []
        if text is not None:
            parts.append(text_part(text))
        if data is not None:
            parts.append(data_part(data))
        task.setdefault("artifacts", []).append(
            {"artifactId": new_id(), "name": name, "description": description, "parts": parts})

    # -- JSON-RPC methods
    def _message_send(self, params: dict) -> dict:
        message = params.get("message")
        if not isinstance(message, dict) or not message.get("parts") or not message.get("messageId"):
            raise A2AError(INVALID_PARAMS, "params.message with messageId and parts is required")
        if message.get("role") != "user":
            raise A2AError(INVALID_PARAMS, "message.role must be 'user' for client messages")

        with self._lock:
            task_id = message.get("taskId")
            is_continuation = bool(task_id)
            if task_id:
                task = self._tasks.get(task_id)
                if task is None:
                    raise A2AError(TASK_NOT_FOUND, f"Task {task_id} not found")
                if task["status"]["state"] in TERMINAL_STATES:
                    raise A2AError(UNSUPPORTED_OPERATION,
                                   f"Task {task_id} is in terminal state {task['status']['state']}")
            else:
                task = {"kind": "task", "id": new_id(),
                        "contextId": message.get("contextId") or new_id(),
                        "status": {"state": TaskState.SUBMITTED, "timestamp": now_iso()},
                        "history": [], "artifacts": [], "metadata": {}}
                self._tasks[task["id"]] = task
            message = copy.deepcopy(message)
            message["taskId"], message["contextId"] = task["id"], task["contextId"]
            task["history"].append(message)
            self.set_status(task, TaskState.WORKING)
            try:
                self.handle_message(message, task, is_continuation)
            except A2AError:
                raise
            except Exception as exc:  # never leak a half-built answer
                self.set_status(task, TaskState.FAILED, f"{self.name} failed safely: {exc}",
                                {"error": type(exc).__name__})
            return self._view(task, params.get("configuration") or {})

    def _tasks_get(self, params: dict) -> dict:
        with self._lock:
            task = self._tasks.get(params.get("id", ""))
            if task is None:
                raise A2AError(TASK_NOT_FOUND, f"Task {params.get('id')} not found")
            return self._view(task, {"historyLength": params.get("historyLength")})

    def _tasks_cancel(self, params: dict) -> dict:
        with self._lock:
            task = self._tasks.get(params.get("id", ""))
            if task is None:
                raise A2AError(TASK_NOT_FOUND, f"Task {params.get('id')} not found")
            if task["status"]["state"] in TERMINAL_STATES:
                raise A2AError(TASK_NOT_CANCELABLE, "Task is already in a terminal state")
            self.set_status(task, TaskState.CANCELED, "Task canceled by client.")
            return self._view(task, {})

    @staticmethod
    def _view(task: dict, configuration: dict) -> dict:
        out = copy.deepcopy(task)
        n = configuration.get("historyLength")
        if isinstance(n, int) and n >= 0:
            out["history"] = out["history"][-n:] if n else []
        return out

    def dispatch_rpc(self, req: Any) -> dict:
        if not isinstance(req, dict) or req.get("jsonrpc") != "2.0" or "method" not in req:
            return {"jsonrpc": "2.0", "id": None,
                    "error": {"code": INVALID_REQUEST, "message": "Invalid JSON-RPC request"}}
        rid = req.get("id")
        methods: dict[str, Callable[[dict], dict]] = {
            "message/send": self._message_send,
            "tasks/get": self._tasks_get,
            "tasks/cancel": self._tasks_cancel,
            "agent/getCard": lambda _p: self.agent_card(),
        }
        fn = methods.get(req["method"])
        try:
            if fn is None:
                raise A2AError(METHOD_NOT_FOUND, f"Method {req['method']} not supported")
            return {"jsonrpc": "2.0", "id": rid, "result": fn(req.get("params") or {})}
        except A2AError as err:
            return {"jsonrpc": "2.0", "id": rid, "error": err.to_dict()}
        except Exception as exc:
            return {"jsonrpc": "2.0", "id": rid,
                    "error": {"code": INTERNAL_ERROR, "message": str(exc)}}

    # -- HTTP transport
    def _handler(self):
        agent = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):  # quiet
                pass

            def _send(self, code: int, body: dict):
                raw = json.dumps(body).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self):
                if self.path in ("/.well-known/agent-card.json", "/.well-known/agent.json"):
                    self._send(200, agent.agent_card())
                else:
                    self._send(404, {"error": "not found"})

            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                try:
                    req = json.loads(self.rfile.read(length) or b"{}")
                except json.JSONDecodeError:
                    self._send(200, {"jsonrpc": "2.0", "id": None,
                                     "error": {"code": PARSE_ERROR, "message": "Parse error"}})
                    return
                self._send(200, agent.dispatch_rpc(req))

        return Handler

    def start(self) -> threading.Thread:
        self._server = ThreadingHTTPServer((self.host, self.port), self._handler())
        self._server.daemon_threads = True
        if self.port == 0:  # ephemeral port (tests)
            self.port = self._server.server_address[1]
            self.url = f"http://{self.host}:{self.port}"
        t = threading.Thread(target=self._server.serve_forever, name=self.name, daemon=True)
        t.start()
        return t

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()
            self._server.server_close()


# ---- Client ----------------------------------------------------------------------
class A2AClientError(Exception):
    pass


class A2AClient:
    """A2A JSON-RPC client. Discovers the endpoint from the Agent Card."""

    def __init__(self, base_url: str, caller: str = "client", timeout: float = 15.0,
                 recorder: Callable[[dict], None] | None = None):
        self.base_url = base_url.rstrip("/")
        self.caller, self.timeout, self.recorder = caller, timeout, recorder
        self._card: dict | None = None

    def _http(self, url: str, body: dict | None = None) -> dict:
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method="POST" if data else "GET",
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read())
        except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
            raise A2AClientError(f"A2A transport error calling {url}: {exc}") from exc

    def get_agent_card(self) -> dict:
        if self._card is None:
            self._card = self._http(self.base_url + "/.well-known/agent-card.json")
        return self._card

    def _rpc(self, method: str, params: dict) -> dict:
        card = self.get_agent_card()
        req = {"jsonrpc": "2.0", "id": new_id(), "method": method, "params": params}
        started = time.perf_counter()
        resp = self._http(card["url"], req)
        elapsed = round((time.perf_counter() - started) * 1000, 1)
        if self.recorder:
            self.recorder({"from": self.caller, "to": card.get("name"), "method": method,
                           "endpoint": card["url"], "latencyMs": elapsed,
                           "request": req, "response": resp})
        if "error" in resp:
            err = resp["error"]
            raise A2AClientError(f"{card.get('name')} returned error {err.get('code')}: {err.get('message')}")
        return resp["result"]

    def send_message(self, message: dict, configuration: dict | None = None) -> dict:
        params = {"message": message}
        if configuration:
            params["configuration"] = configuration
        return self._rpc("message/send", params)

    def get_task(self, task_id: str, history_length: int | None = None) -> dict:
        params: dict = {"id": task_id}
        if history_length is not None:
            params["historyLength"] = history_length
        return self._rpc("tasks/get", params)

    def cancel_task(self, task_id: str) -> dict:
        return self._rpc("tasks/cancel", {"id": task_id})
