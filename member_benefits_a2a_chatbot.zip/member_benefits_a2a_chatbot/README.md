# Member Benefits Assistant — A2A Disambiguation Chatbot

A Python chatbot that implements the *Member Utterance Disambiguation Agent* white paper:
**disambiguate before dispatch**, dispatch to the Benefits Agent only at **≥ 80% confidence**,
ask **at most one** clarifying question, and otherwise **transfer to a live agent — never guess**.

Agents talk to each other with Google's **Agent2Agent (A2A) protocol** (v0.3.0, JSON-RPC 2.0 binding).
No third-party packages are needed; it runs on the Python 3.10+ standard library.

## Quick start

```bash
python run.py                 # opens http://127.0.0.1:8000
python run.py --no-browser
python -m unittest discover -s tests -v    # 15 end-to-end tests over real A2A HTTP calls
```
On Windows you can also double-click `run.bat`.

## Architecture

```
 Browser UI (chat + history + trace)
      │  REST
 Orchestrator (A2A client) ──message/send──► Intake Agent          :8101  capture, PHI strip, signals
      │                     ──message/send──► Disambiguation Agent  :8102  ground, score, gate
      │                          ▲  input-required (one question) → reply continues same taskId
      │                     ──message/send──► Dispatch Agent        :8103  re-check gate, route
      │                                            ├─message/send──► Benefits Agent :8104  plan lookup
      │                                            └─────────────► Live advocate queue (SQLite)
```

Each agent is its own A2A server with an Agent Card at `/.well-known/agent-card.json`.

| Agent | Skill | Responsibility |
|---|---|---|
| Intake Agent | `captureUtterance` | PHI/PII redaction, normalization, negation, time anchoring, slot signals, member context. Handles greetings/help/context statements. Never answers benefits. |
| Disambiguation Agent | `resolveBeforeDispatch` | Grounds in chat history, vector memory, profile, and `ontology.json`; computes the composite confidence; returns *released*, *awaiting-clarification* (A2A `input-required`), or *live-agent-transfer*. |
| Dispatch Agent | `dispatchResolvedIntent` | Re-validates the gate (defense in depth), calls the Benefits Agent over A2A, or creates a live-advocate handoff with full context. |
| Benefits Agent | `benefitLookup` | Answers only released intents from the system of record. Rejects raw utterances; fails (→ live agent) if a value isn’t on file. |

## Confidence score (white paper §8.4.1)

| Factor | Weight |
|---|---:|
| Intent match strength | 30% |
| Required-slot completion | 25% |
| Context agreement | 20% |
| Ontology alignment | 15% |
| Evidence consistency and ambiguity control | 10% |
| **Total** | **100%** |

The score is calculated by application code from traced evidence, never self-reported by a model.
A missing required slot, an unresolved conflict, or competing intents cap the score at 0.79, so
“dispatch when ≥ 0.80” is always consistent with the gate. Threshold, weights, and the
one-question ceiling live in `config.py`, and clients cannot override them.

## No-hallucination controls

- Every slot records its grounding source (utterance, clarification, chat history, profile, vector memory). Per-slot allowed sources are set in `ontology.json`. For example, vector memory can corroborate a specialty but can’t fill it.
- The Benefits Agent answers only from `benefit_plans.json`. If a plan, year, specialty, service, or drug isn’t on file, the task fails and the member is transferred.
- The optional LLM advisor (`USE_LLM=1` plus Azure OpenAI settings) can only pick from the deterministic candidates. It can confirm or *lower* confidence, never raise it or supply values.

Live-agent transfer happens when: the intent isn’t identified, there are competing intents, coverage is inactive,
two or more slots are missing, the single question can’t reach 80%, the clarification doesn’t resolve it,
or the Benefits Agent can’t verify the value.

## Demo scripts (pick the member in the sidebar)

| Member | Say | Outcome |
|---|---|---|
| Jordan Lee (PPO) | “I need a knee eval”, then “What’s my copay to see a specialist?” | Dispatched at ~95%, specialty grounded from chat history (the white paper’s worked example) |
| Jordan Lee (PPO) | “What’s my specialist copay?” → “cardiologist” | One question, then dispatched |
| Jordan Lee (PPO) | “What’s my specialist copay?” → “not sure” | Live advocate |
| Taylor Brooks (PPO, no memory) | “What’s my specialist copay?” | Two slots missing, so live advocate |
| Sam Rivera (HMO) | “How much is my deductible?” | Network tier grounded from the HMO plan rule |
| Any | “Do I need pre-approval for an MRI?” / “Is my Lipitor covered?” | Ontology synonyms, answered |
| Any | “What’s my in-network copay for an allergist?” | Not in plan data, so live advocate, no guess |
| Casey Morgan (inactive) | “What is my deductible?” | Live advocate |

## Project layout

```
a2a_protocol/protocol.py   A2A server/client (Agent Card, message/send, tasks/get, tasks/cancel)
agents/                    intake, disambiguation, dispatch, benefits agents
core/                      signals, confidence, redaction, vector memory, prompt builder, LLM advisor, SQLite store
data/                      ontology.json, benefit_plans.json, members.json, member_memory.json  (FICTIONAL sample data)
web/                       orchestrator, HTTP server, static UI (index.html, app.css, app.js)
tests/test_flows.py        end-to-end tests
```

## Moving toward production

- **A2A SDK:** the wire format is isolated in `a2a_protocol/protocol.py`, so you can swap in the official `a2a-sdk` or a newer protocol version without changing agent logic.
- **Data:** replace the JSON files with the plan administration API, eligibility service, and an embedding index (for example Azure AI Search) filtered by member token.
- **Security:** add authentication to the Agent Cards (`securitySchemes`), TLS, and RBAC. Validate the ontology and benefit data with clinical and benefits SMEs, and calibrate the weights on a labeled test set.
- **Live agents:** point `Store.create_handoff` at your contact-center queue.

All members, benefits, and memory entries are fictional sample data.
