"""Benefits Agent - domain agent (white paper Section 8.3).

Accepts ONLY a disambiguated, released intent with populated slots - never a raw
utterance. Answers exclusively from the benefit system of record; if a value is not
present it fails the task rather than estimating (no hallucination).
"""
from __future__ import annotations

import config
from a2a_protocol.protocol import A2AAgent, TaskState, get_data
from core import data_store


def _money(v) -> str:
    return f"${v:,.0f}"


def _cost_phrase(entry: dict) -> str:
    if entry["type"] == "copay":
        return f"a {_money(entry['amount'])} copay"
    text = f"{entry['percent']}% coinsurance"
    if entry.get("afterDeductible"):
        text += " after your deductible"
    if entry.get("maxPerFill"):
        text += f" (up to {_money(entry['maxPerFill'])} per fill)"
    return text


class NoPlanData(Exception):
    pass


class BenefitsAgent(A2AAgent):
    name = "Benefits Agent"
    description = ("Executes benefit lookups for resolved intents against the plan system of record. "
                   "Rejects unresolved utterances; never estimates missing values.")
    skills = [{
        "id": "benefitLookup",
        "name": "Benefit lookup",
        "description": "Copays, coinsurance, deductibles, out-of-pocket maximums, ER cost, prior authorization, Rx coverage.",
        "tags": ["benefits", "domain-agent", "plan-lookup"],
        "examples": ['{"resolvedIntent": "GetSpecialistCopay", "slots": {"providerType": "Orthopedic Specialist"}}'],
        "inputModes": ["application/json"],
        "outputModes": ["text/plain", "application/json"],
    }]

    def handle_message(self, message: dict, task: dict, is_continuation: bool) -> None:
        req = get_data(message)
        if not req.get("resolvedIntent") or req.get("dispatchState") != "released":
            self.set_status(task, TaskState.REJECTED,
                            "Benefits Agent accepts only disambiguated, released intents.")
            return
        if float(req.get("confidence", 0)) < config.CONFIDENCE_THRESHOLD:
            self.set_status(task, TaskState.REJECTED, "Confidence below dispatch threshold.")
            return
        slots = req.get("slots") or {}
        plan = data_store.benefit_plans().get(slots.get("planId", ""))
        try:
            if plan is None:
                raise NoPlanData(f"no benefit data for plan {slots.get('planId')}")
            if slots.get("planYear") and slots["planYear"] != plan["planYear"]:
                raise NoPlanData(f"no benefit data for plan year {slots['planYear']}")
            answer, values = self._lookup(req["resolvedIntent"], slots, plan)
        except NoPlanData as exc:
            self.set_status(task, TaskState.FAILED, f"No verified benefit data: {exc}.",
                            {"reason": "no-plan-data", "detail": str(exc)})
            return
        answer += f" Source: {plan['documentRef']}."
        self.add_artifact(task, "benefit-answer", text=answer, data={
            "intent": req["resolvedIntent"], "answerText": answer, "values": values,
            "planName": plan["planName"], "planYear": plan["planYear"], "documentRef": plan["documentRef"]})
        self.set_status(task, TaskState.COMPLETED, answer)

    @staticmethod
    def _need(d: dict, key: str, what: str):
        if not isinstance(d, dict) or key not in d:
            raise NoPlanData(what)
        return d[key]

    def _lookup(self, intent: str, s: dict, plan: dict) -> tuple[str, dict]:
        name, year = plan["planName"], plan["planYear"]
        tier = s.get("networkTier")
        if tier == "out-of-network" and plan.get("networkRule") == "in-network-only":
            return (f"Your {name} plan ({year}) covers in-network providers only, so out-of-network "
                    "visits are not covered except for emergencies.", {"covered": False})
        if intent == "GetSpecialistCopay":
            e = self._need(self._need(plan["specialistVisit"], tier, f"{tier} specialist benefits"),
                           s["providerType"], f"{s['providerType']} benefit")
            text = f"For an {tier} {s['providerType']} visit on your {name} plan ({year}), you pay {_cost_phrase(e)}."
            if e.get("referralRequired"):
                text += " A referral from your primary care physician is required."
            return text, e
        if intent == "GetPrimaryCareCopay":
            e = self._need(plan["primaryCareVisit"], tier, f"{tier} primary care benefit")
            return f"For an {tier} primary care visit on your {name} plan ({year}), you pay {_cost_phrase(e)}.", e
        if intent == "GetDeductible":
            e = self._need(plan["deductible"], tier, f"{tier} deductible")
            return (f"Your {year} {tier} deductible on the {name} plan is {_money(e['individual'])} individual / "
                    f"{_money(e['family'])} family. Year-to-date amounts met are not available in this channel.", e)
        if intent == "GetOutOfPocketMax":
            e = self._need(plan["outOfPocketMax"], tier, f"{tier} out-of-pocket maximum")
            return (f"Your {year} {tier} out-of-pocket maximum on the {name} plan is {_money(e['individual'])} "
                    f"individual / {_money(e['family'])} family.", e)
        if intent == "GetEmergencyRoomCost":
            e = self._need(plan, "emergencyRoom", "emergency room benefit")
            return f"An emergency room visit on your {name} plan ({year}) is {_cost_phrase(e)}. {e.get('note', '')}".strip(), e
        if intent == "CheckPriorAuthorization":
            required = self._need(plan["priorAuthorization"], s["serviceType"], f"prior authorization rule for {s['serviceType']}")
            verdict = "requires" if required else "does not require"
            return (f"{'Yes' if required else 'No'} \u2014 {s['serviceType']} {verdict} prior authorization on your "
                    f"{name} plan ({year}).", {"priorAuthRequired": required})
        if intent == "GetPrescriptionCoverage":
            e = self._need(plan["pharmacy"], s["drugName"], f"formulary entry for {s['drugName']}")
            text = f"{s['drugName'].capitalize()} is covered on your {name} plan ({year}) as {e['tier']} with {_cost_phrase(e)}."
            if e.get("priorAuthRequired"):
                text += " Prior authorization is required."
            return text, e
        raise NoPlanData(f"unsupported intent {intent}")
