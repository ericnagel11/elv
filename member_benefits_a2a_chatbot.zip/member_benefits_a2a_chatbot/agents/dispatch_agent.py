"""Dispatch Agent - Stage 7 (Respond).

Re-validates the confidence gate (defense in depth), then either:
  * dispatches the released intent to the Benefits Agent over A2A, or
  * transfers the interaction to a live member advocate with a full handoff payload.

The Benefits Agent is never called below 0.80 or with ungrounded slots, and if it
cannot verify an answer the member is transferred - never given a guess.
"""
from __future__ import annotations

import config
from a2a_protocol.protocol import (A2AAgent, A2AClient, A2AClientError, TaskState, artifact_data,
                                   data_part, get_data, get_text, make_message)
from core.store import Store

TRANSFER_TEXT = ("I want to make sure you get an accurate answer, so I\u2019m connecting you with a live member "
                 "advocate. I\u2019ve shared what we discussed so you won\u2019t need to repeat yourself. "
                 "Your reference number is {ticket}.")

REASON_TEXT = {
    "member-not-eligible-or-not-authorized": "coverage is not active or benefits access is not authorized",
    "intent-not-identified": "the request could not be matched to a supported benefit question",
    "competing-intents": "the request contains more than one benefit question",
    "clarification-did-not-resolve": "the clarifying answer did not resolve the request",
    "single-question-cannot-reach-threshold": "one question would not be enough to be certain",
    "no-single-decisive-slot": "more than one required detail is missing or conflicting",
    "gate-validation-failed": "the confidence gate re-check failed",
    "benefits-agent-could-not-verify": "the benefit could not be verified in the plan system of record",
    "benefits-agent-unavailable": "the Benefits Agent was unavailable",
}


class DispatchAgent(A2AAgent):
    name = "Dispatch Agent"
    description = ("Routes disambiguated intents: dispatches to the Benefits Agent at confidence >= 0.80 with "
                   "grounded slots; otherwise transfers to a live member advocate with trace.")
    skills = [{
        "id": "dispatchResolvedIntent",
        "name": "Dispatch resolved intent",
        "description": "Confidence-gate re-validation, Benefits Agent dispatch over A2A, live-agent handoff.",
        "tags": ["dispatch", "routing", "live-agent-handoff"],
        "examples": ['{"resolution": {"dispatchState": "released", "confidence": 0.94}}'],
        "inputModes": ["application/json"],
        "outputModes": ["text/plain", "application/json"],
    }]

    def __init__(self, host: str, port: int, benefits_url: str, store: Store):
        super().__init__(host, port)
        self.benefits_url, self.store = benefits_url, store

    def handle_message(self, message: dict, task: dict, is_continuation: bool) -> None:
        req = get_data(message)
        res = req.get("resolution") or {}
        ctx = req.get("memberContext") or {}
        exchanges: list[dict] = []
        gate = self._gate(res)

        if res.get("dispatchState") == "released" and gate["passed"]:
            client = A2AClient(self.benefits_url, caller=self.name, recorder=exchanges.append)
            payload = {k: res.get(k) for k in ("resolvedIntent", "slots", "confidence", "ontologyRefs", "dispatchState")}
            try:
                btask = client.send_message(make_message("user", [data_part(payload)], context_id=task["contextId"]))
                state = btask["status"]["state"]
            except A2AClientError as exc:
                btask, state = {"error": str(exc)}, "unavailable"
            if state == TaskState.COMPLETED:
                answer = artifact_data(btask, "benefit-answer")
                out = {"outcome": "answered", "responseText": answer["answerText"], "benefits": answer,
                       "benefitsTaskId": btask["id"], "gateCheck": gate, "downstreamExchanges": exchanges}
                self._finish(task, out)
                return
            reason = "benefits-agent-unavailable" if state == "unavailable" else "benefits-agent-could-not-verify"
            detail = get_text(btask.get("status", {}).get("message")) if isinstance(btask, dict) else ""
            self._transfer(task, req, res, ctx, reason, gate, exchanges, detail)
            return

        reason = (res.get("liveAgentTransfer") or {}).get("reason") or "gate-validation-failed"
        self._transfer(task, req, res, ctx, reason, gate, exchanges)

    @staticmethod
    def _gate(res: dict) -> dict:
        required = res.get("requiredSlots") or []
        ungrounded = [s for s in required if s not in (res.get("slots") or {})
                      or not (res.get("slotEvidence") or {}).get(s, {}).get("source")]
        checks = {
            "confidenceAtOrAboveThreshold": float(res.get("confidence") or 0) >= config.CONFIDENCE_THRESHOLD,
            "allRequiredSlotsGrounded": not ungrounded,
            "intentResolved": bool(res.get("resolvedIntent")),
            "noClarificationPending": res.get("clarification") in (None, ""),
        }
        return {"passed": all(checks.values()), "checks": checks, "ungroundedSlots": ungrounded,
                "threshold": config.CONFIDENCE_THRESHOLD, "confidence": res.get("confidence")}

    def _transfer(self, task, req, res, ctx, reason, gate, exchanges, detail: str = "") -> None:
        payload = {
            "originalUtterance": req.get("utterance"),          # already PHI-stripped
            "chatHistory": req.get("chatHistory", []),
            "resolvedIntentCandidate": res.get("resolvedIntent"),
            "groundedSlots": res.get("slots"),
            "missingOrConflictingSlots": (res.get("liveAgentTransfer") or {}).get("missingSlots") or gate["ungroundedSlots"],
            "confidence": res.get("confidence"),
            "confidenceFactors": res.get("confidenceFactors"),
            "redactions": (res.get("trace") or {}).get("redactions"),
            "ontologyVersion": (res.get("trace") or {}).get("ontologyVersion"),
            "detail": detail,
        }
        handoff = self.store.create_handoff(req.get("sessionId", ""), ctx.get("memberToken", ""), reason, payload)
        handoff["reasonText"] = REASON_TEXT.get(reason, reason)
        out = {"outcome": "live-agent-transfer", "responseText": TRANSFER_TEXT.format(ticket=handoff["ticketId"]),
               "handoff": handoff, "gateCheck": gate, "downstreamExchanges": exchanges}
        self._finish(task, out)

    def _finish(self, task: dict, out: dict) -> None:
        self.add_artifact(task, "dispatch-result", data=out, description="Dispatch outcome and downstream A2A exchanges")
        self.set_status(task, TaskState.COMPLETED, out["responseText"])
