"""Intake Agent - Stage 1 (Capture) and Stage 2 (Interpret).

Receives the raw member utterance, strips PHI/PII, normalizes the text, extracts
deterministic utterance signals, and attaches the tokenized member context.
It never answers benefit questions.
"""
from __future__ import annotations

from a2a_protocol.protocol import A2AAgent, TaskState, get_data, get_text
from core import data_store, redaction, signals

GREETING_REPLY = ("Hi! I can help with your plan benefits \u2014 copays, deductibles, out-of-pocket maximums, "
                  "prior authorization, emergency room costs, and prescription coverage. What would you like to know?")
HELP_REPLY = ("Ask me about your benefits in your own words, for example \u201cWhat\u2019s my copay to see a specialist?\u201d "
              "or \u201cDo I need pre-approval for an MRI?\u201d. If anything is unclear I\u2019ll ask one short question; "
              "if I still can\u2019t be certain, I\u2019ll connect you with a live member advocate rather than guess.")


class IntakeAgent(A2AAgent):
    name = "Intake Agent"
    description = ("Captures member utterances, strips PHI/PII, normalizes text, extracts deterministic utterance "
                   "signals, and attaches tokenized member context. Never answers benefit questions.")
    skills = [{
        "id": "captureUtterance",
        "name": "Capture and interpret member utterance",
        "description": "PHI/PII redaction, normalization, negation, time anchoring, reference and slot signals.",
        "tags": ["intake", "phi-redaction", "normalization", "utterance-signals"],
        "examples": ["What's my copay to see a specialist?", "I need a knee eval"],
        "inputModes": ["text/plain", "application/json"],
        "outputModes": ["application/json"],
    }]

    def handle_message(self, message: dict, task: dict, is_continuation: bool) -> None:
        raw = get_text(message)
        meta = get_data(message)
        member = data_store.member_by_id(meta.get("memberId", ""))
        if member is None:
            self.set_status(task, TaskState.REJECTED, "Unknown or unauthenticated member.")
            return
        if not raw:
            self.set_status(task, TaskState.REJECTED, "Empty utterance.")
            return

        redacted, redactions = redaction.redact(raw)
        ont = data_store.ontology()
        norm = signals.normalize(redacted)
        negations = signals.detect_negation(norm)
        slot_values = signals.extract_slot_values(norm, ont, negations)
        concepts = signals.match_concepts(norm, ont, negations, slot_values)
        utype = signals.classify(redacted, norm, concepts, slot_values)
        strong = [c for c in concepts if c["matchType"] in ("synonym", "slot-implied")]

        member_context = {k: member[k] for k in ("memberToken", "planId", "planType", "eligibility",
                                                 "coverage", "language", "authorizationScope")}
        envelope = {
            "redactedUtterance": redacted,
            "redactionCount": len(redactions),
            "redactions": redactions,
            "normalized": norm,
            "utteranceType": utype,
            "signals": {
                "negations": [{"cue": n["cue"], "span": n["span"]} for n in negations],
                "timeAnchor": signals.anchor_time(norm),
                "references": signals.find_references(norm),
                "candidateSlots": slot_values,
                "hypothetical": signals.is_hypothetical(norm),
                "detectedConcept": strong[0]["conceptId"] if strong else None,
            },
            "memberContext": member_context,
            "channel": meta.get("channel", "web-chat"),
        }
        reply = None
        if utype == "greeting":
            reply = GREETING_REPLY
        elif utype == "help":
            reply = HELP_REPLY
        elif utype == "context":
            noted = [v for s in slot_values.values() for v in s["values"]]
            reply = (f"Thanks \u2014 I\u2019ve noted: {', '.join(noted)}. "
                     "What would you like to know about your benefits for this?")
        envelope["reply"] = reply
        self.add_artifact(task, "intake-envelope", data=envelope,
                          description="PHI-stripped utterance, deterministic signals, tokenized member context")
        self.set_status(task, TaskState.COMPLETED, reply or "Utterance captured and interpreted.")
