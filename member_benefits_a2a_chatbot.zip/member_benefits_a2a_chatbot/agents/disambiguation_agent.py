"""Disambiguation Agent - Stages 3-6 (Ground, Enrich, Prompt, Resolve) + Confidence Gate.

Skill `resolveBeforeDispatch`. Grounds the utterance in chat history, member-scoped
vector memory, member profile, and the versioned ontology; computes the composite
confidence score; and returns exactly one of three outcomes:

  * released               (confidence >= 0.80, all required slots grounded)  -> task completed
  * awaiting-clarification (one decisive slot, one question, first attempt)   -> task input-required
  * live-agent-transfer    (cannot be disambiguated without guessing)         -> task completed

No value is ever invented: every slot carries the source it was grounded from.
"""
from __future__ import annotations

import copy

import config
from a2a_protocol.protocol import A2AAgent, TaskState, get_data
from core import confidence, data_store, llm_adapter, prompt_builder, signals, vector_memory

_PRECEDENCE = ["clarification", "utterance", "chatHistory", "profile", "vectorMemory"]


class DisambiguationAgent(A2AAgent):
    name = "Disambiguation Agent"
    description = ("Resolves a PHI-stripped member utterance into one canonical intent with grounded slots and a "
                   "composite confidence score. Dispatch is released only at >= 0.80; otherwise one clarifying "
                   "question or a live-agent transfer. Never guesses.")
    skills = [{
        "id": "resolveBeforeDispatch",
        "name": "Resolve before dispatch",
        "description": "Grounded intent resolution with confidence gate, one-question ceiling, and live-agent fallback.",
        "tags": ["disambiguation", "confidence-gate", "ontology", "healthcare-benefits"],
        "examples": ["What's my copay to see a specialist?"],
        "inputModes": ["application/json"],
        "outputModes": ["application/json"],
    }]

    # ------------------------------------------------------------------ A2A entry
    def handle_message(self, message: dict, task: dict, is_continuation: bool) -> None:
        req = get_data(message)
        state = task["metadata"].setdefault("resolution", {})
        if not is_continuation:
            state.update({"request": req, "attempts": 0, "clarifications": {}})
        else:
            pending_slot = state.get("pendingSlot")
            answer = req.get("normalized") or signals.normalize(req.get("utterance", ""))
            values = signals.extract_slot_values(answer, data_store.ontology()).get(pending_slot, {}).get("values", [])
            state["attempts"] += 1
            if len(values) == 1:
                state["clarifications"][pending_slot] = {"value": values[0], "detail": f"member answered: '{answer}'"}
            state["lastAnswer"] = answer
            # refresh history with the turns that happened since the question
            state["request"]["chatHistory"] = req.get("chatHistory", state["request"].get("chatHistory", []))

        result = self._resolve(state)
        self.add_artifact(task, "disambiguation-result", data=result,
                          description="A2A response contract: resolved intent, slots, confidence, trace")
        if result["dispatchState"] == "awaiting-clarification":
            state["pendingSlot"] = result["clarificationSlot"]
            self.set_status(task, TaskState.INPUT_REQUIRED, result["clarification"],
                            {"clarificationSlot": result["clarificationSlot"], "confidence": result["confidence"]})
        else:
            self.set_status(task, TaskState.COMPLETED,
                            "Intent resolved; release for dispatch." if result["dispatchState"] == "released"
                            else "Cannot disambiguate without guessing; transfer to a live agent.")

    # ------------------------------------------------------------------ resolution
    def _resolve(self, state: dict) -> dict:
        req = state["request"]
        ont = data_store.ontology()
        norm = req.get("normalized") or signals.normalize(req.get("utterance", ""))
        member_ctx = req.get("memberContext") or {}
        history = [t for t in (req.get("chatHistory") or [])][-2 * config.CHAT_HISTORY_TURNS:]
        member_turns = [t for t in history if t.get("role") == "member"]
        client_threshold = req.get("confidenceThreshold")
        negations = signals.detect_negation(norm)
        utter_slots = signals.extract_slot_values(norm, ont, negations)
        candidates = signals.match_concepts(norm, ont, negations, utter_slots)
        references = signals.find_references(norm)
        flags = {"hypothetical": signals.is_hypothetical(norm)}
        binding = None

        # Resolve reference: bind "it / that one" to the most recent concept in chat history
        if references and (not candidates or candidates[0]["score"] < config.INTENT_FLOOR):
            for idx, turn in enumerate(reversed(member_turns), start=1):
                hc = signals.match_concepts(signals.normalize(turn["text"]), ont)
                if hc and hc[0]["score"] >= config.INTENT_FLOOR:
                    top = dict(hc[0], score=0.80, alignment=0.75, matchType="reference",
                               matched=f"'{references[0]}' -> turn -{idx}")
                    candidates = [top] + [c for c in candidates if c["conceptId"] != top["conceptId"]]
                    binding = {"expression": references[0], "boundTo": top["canonical"], "turn": -idx}
                    break
            else:
                flags["unresolvedReference"] = True

        identified = bool(candidates) and candidates[0]["score"] >= config.INTENT_FLOOR
        if identified and len(candidates) > 1 and candidates[1]["score"] >= config.INTENT_FLOOR \
                and candidates[1]["score"] / candidates[0]["score"] >= config.COMPETING_INTENT_RATIO:
            flags["competingIntents"] = True
        concept = next((c for c in ont["concepts"] if identified and c["id"] == candidates[0]["conceptId"]), None)
        required = concept["requiredSlots"] if concept else []

        memory_hits = vector_memory.retrieve(member_ctx.get("memberToken", ""), norm,
                                             concept["id"] if concept else None,
                                             top_k=(req.get("memoryRefs") or {}).get("topK", config.VECTOR_TOP_K))
        slots = self._ground_slots(required, ont, utter_slots, member_turns, member_ctx, memory_hits,
                                   state.get("clarifications", {}))

        prompt = prompt_builder.build(
            {"normalized": norm, "negations": [n["span"] for n in negations], "references": references,
             "timeAnchor": signals.anchor_time(norm), "candidateSlots": utter_slots,
             "candidates": [{"intent": c["intent"], "score": c["score"]} for c in candidates[:3]]},
            ont["concepts"], member_ctx, memory_hits, history)
        advisor = {"used": False}
        if identified and llm_adapter.enabled():
            advisor = llm_adapter.advise(prompt, [c["intent"] for c in candidates])
            if advisor.get("valid") and advisor.get("intent") != candidates[0]["intent"]:
                flags["llmDisagreement"] = True
        if not identified:
            flags["intentNotIdentified"] = True

        score = confidence.compute(candidates if identified else [], required, slots, flags)
        result = {
            "resolvedIntent": concept["intent"] if concept else None,
            "canonicalConcept": concept["canonical"] if concept else None,
            "conceptId": concept["id"] if concept else None,
            "slots": {k: v["value"] for k, v in slots.items() if v.get("value") is not None},
            "slotEvidence": slots,
            "requiredSlots": required,
            "confidence": score["confidence"],
            "rawConfidence": score["rawConfidence"],
            "threshold": config.CONFIDENCE_THRESHOLD,
            "confidenceFactors": score["factors"],
            "capReasons": score["capReasons"],
            "penalties": score["penalties"],
            "ontologyRefs": ([{"canonical": concept["canonical"], "codeSystem": concept["codeSystem"]}] if concept else [])
                            + [{"canonical": v["value"], "codeSystem": ont["slots"][k].get("codeSystem", "Benefit Plan")}
                               for k, v in slots.items() if v.get("value") and ont["slots"].get(k, {}).get("codeSystem")],
            "clarification": None,
            "clarificationSlot": None,
            "maxClarifications": config.MAX_CLARIFICATIONS,
            "clarificationAttempts": state.get("attempts", 0),
            "candidates": candidates[:4],
            "liveAgentTransfer": None,
            "trace": {
                "ontologyVersion": ont["version"],
                "requestedOntologyVersion": req.get("ontologyVersion"),
                "redactions": req.get("redactionCount", 0),
                "policyTags": req.get("policyTags", []),
                "referenceBinding": binding,
                "memoryHits": memory_hits,
                "historyTurnsUsed": len(member_turns),
                "advisor": advisor,
                "clientThresholdIgnored": (client_threshold is not None and client_threshold != config.CONFIDENCE_THRESHOLD),
                "zeroShotPrompt": prompt,
            },
        }

        # -------- Confidence gate (white paper Sections 8.4, 8.5, 9, 10) --------
        eligible = member_ctx.get("eligibility") == "active" and "benefits:read" in (member_ctx.get("authorizationScope") or [])
        problem_slots = sorted(set(score["missingSlots"]) | set(score["conflictingSlots"]))
        if not eligible:
            return self._transfer(result, "member-not-eligible-or-not-authorized", problem_slots)
        if not identified:
            return self._transfer(result, "intent-not-identified", problem_slots)
        if flags.get("competingIntents"):
            return self._transfer(result, "competing-intents", problem_slots)
        if score["confidence"] >= config.CONFIDENCE_THRESHOLD and not problem_slots:
            result["dispatchState"] = "released"
            return result
        if state.get("attempts", 0) >= config.MAX_CLARIFICATIONS:
            return self._transfer(result, "clarification-did-not-resolve", problem_slots)
        if len(problem_slots) == 1:
            slot = problem_slots[0]
            question = ont["slots"].get(slot, {}).get("clarificationQuestion")
            projected = confidence.project_with(candidates, required, slots, flags, slot)
            result["trace"]["projectedConfidenceIfAnswered"] = projected
            if question and projected >= config.CONFIDENCE_THRESHOLD:
                result.update(dispatchState="awaiting-clarification", clarification=question, clarificationSlot=slot)
                return result
            return self._transfer(result, "single-question-cannot-reach-threshold", problem_slots)
        return self._transfer(result, "no-single-decisive-slot", problem_slots)

    @staticmethod
    def _transfer(result: dict, reason: str, problem_slots: list[str]) -> dict:
        result["dispatchState"] = "live-agent-transfer"
        result["liveAgentTransfer"] = {
            "reason": reason,
            "missingSlots": result.get("requiredSlots") and [s for s in problem_slots if s not in result["slots"]],
            "conflictingSlots": [s for s, v in result["slotEvidence"].items() if v.get("conflict")],
            "confidence": result["confidence"],
            "confidenceFactors": result["confidenceFactors"],
        }
        return result

    # ------------------------------------------------------------------ grounding
    def _ground_slots(self, required, ont, utter_slots, member_turns, member_ctx, memory_hits, clarifications) -> dict:
        slots: dict[str, dict] = {}
        for name in required:
            spec = ont["slots"].get(name, {})
            fill_from = set(spec.get("groundingSources", []))
            evidence: list[dict] = []
            conflict_values: list[str] = []

            if name in clarifications:
                evidence.append({"source": "clarification", "value": clarifications[name]["value"],
                                 "detail": clarifications[name]["detail"]})
            if name in utter_slots:
                vals = utter_slots[name]["values"]
                if len(vals) > 1:
                    conflict_values = vals
                else:
                    evidence.append({"source": "utterance", "value": vals[0],
                                     "detail": f"phrase '{utter_slots[name]['phrases'][0]}'"})
            for idx, turn in enumerate(reversed(member_turns), start=1):
                tv = signals.extract_slot_values(signals.normalize(turn["text"]), ont).get(name)
                if tv and len(tv["values"]) == 1:
                    evidence.append({"source": "chatHistory", "value": tv["values"][0],
                                     "detail": f"turn -{idx}: '{turn['text'][:80]}'"})
                    break
            prof = self._profile_value(name, member_ctx)
            if prof:
                evidence.append({"source": "profile", **prof})
            for hit in memory_hits:
                if name in hit["slots"]:
                    evidence.append({"source": "vectorMemory", "value": hit["slots"][name],
                                     "detail": f"{hit['id']} (relevance {hit['relevance']})"})
                    break

            # A clarification answer resolves an earlier same-source conflict
            if conflict_values and not any(e["source"] == "clarification" for e in evidence):
                slots[name] = {"value": None, "source": None, "evidence": evidence,
                               "conflict": True, "conflictValues": conflict_values}
                continue
            chosen = None
            for src in _PRECEDENCE:
                if src not in fill_from:
                    continue
                chosen = next((e for e in evidence if e["source"] == src), None)
                if chosen:
                    break
            slots[name] = {"value": chosen["value"] if chosen else None,
                           "source": chosen["source"] if chosen else None,
                           "evidence": copy.deepcopy(evidence), "conflict": False}
        return slots

    @staticmethod
    def _profile_value(name: str, ctx: dict) -> dict | None:
        if name == "planId" and ctx.get("planId"):
            return {"value": ctx["planId"], "detail": "member profile: active plan"}
        if name == "planYear" and (ctx.get("coverage") or {}).get("planYear"):
            return {"value": ctx["coverage"]["planYear"], "detail": "member profile: current coverage period"}
        if name == "networkTier" and ctx.get("planType") == "HMO":
            return {"value": "in-network", "detail": "plan rule: HMO covers in-network providers only"}
        return None
