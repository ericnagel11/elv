"""End-to-end tests over real A2A HTTP calls (ephemeral ports, temp database).

    python -m unittest discover -s tests -v
"""
import json
import os
import sys
import tempfile
import unittest
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config  # noqa: E402
from core.store import Store  # noqa: E402
from run import build  # noqa: E402


class FlowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.store = Store(os.path.join(cls.tmp.name, "test.db"))
        cls.orch, cls.agents = build(cls.store, "127.0.0.1",
                                     {"intake": 0, "disambiguation": 0, "dispatch": 0, "benefits": 0})

    @classmethod
    def tearDownClass(cls):
        for a in cls.agents:
            a.stop()
        cls.store._db.close()
        cls.tmp.cleanup()

    def turn(self, sid, text):
        return self.orch.handle_turn(sid, text)["assistant"]

    def new(self, member="M1001"):
        return self.store.create_session(member)["id"]

    # --- A2A conformance -------------------------------------------------------
    def test_agent_cards_discoverable(self):
        for a in self.agents:
            with urllib.request.urlopen(a.url + "/.well-known/agent-card.json") as r:
                card = json.loads(r.read())
            self.assertEqual(card["protocolVersion"], "0.3.0")
            self.assertTrue(card["skills"])
            self.assertEqual(card["preferredTransport"], "JSONRPC")

    def test_unknown_method_returns_jsonrpc_error(self):
        a = self.agents[0]
        req = urllib.request.Request(a.url + "/", data=json.dumps(
            {"jsonrpc": "2.0", "id": 1, "method": "nope", "params": {}}).encode(),
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req) as r:
            self.assertEqual(json.loads(r.read())["error"]["code"], -32601)

    # --- White paper worked example (Section 12) --------------------------------
    def test_worked_example_history_grounded_dispatch(self):
        sid = self.new("M1001")
        ack = self.turn(sid, "I need a knee eval")
        self.assertEqual(ack["meta"]["outcome"], "context")
        r = self.turn(sid, "What's my copay to see a specialist?")
        res = r["meta"]["resolution"]
        self.assertEqual(r["meta"]["outcome"], "answered")
        self.assertEqual(res["resolvedIntent"], "GetSpecialistCopay")
        self.assertEqual(res["slots"]["providerType"], "Orthopedic Specialist")
        self.assertEqual(res["slotEvidence"]["providerType"]["source"], "chatHistory")
        self.assertGreaterEqual(res["confidence"], 0.80)
        self.assertIn("$50", r["text"])

    def test_confidence_weights_total_100(self):
        self.assertAlmostEqual(sum(config.CONFIDENCE_WEIGHTS.values()), 1.0)

    # --- One clarifying question, then dispatch ---------------------------------
    def test_single_clarification_then_dispatch(self):
        sid = self.new("M1001")
        q = self.turn(sid, "What's my copay to see a specialist?")
        self.assertEqual(q["meta"]["outcome"], "clarification")
        self.assertLess(q["meta"]["resolution"]["confidence"], 0.80)
        self.assertEqual(q["meta"]["resolution"]["clarificationSlot"], "providerType")
        a = self.turn(sid, "a cardiologist")
        self.assertEqual(a["meta"]["outcome"], "answered")
        self.assertEqual(a["meta"]["resolution"]["slotEvidence"]["providerType"]["source"], "clarification")

    # --- Live agent fallbacks (no hallucination) ---------------------------------
    def test_clarification_unresolved_goes_to_live_agent(self):
        sid = self.new("M1001")
        self.turn(sid, "What's my copay to see a specialist?")
        r = self.turn(sid, "not sure")
        self.assertEqual(r["meta"]["outcome"], "live-agent-transfer")
        self.assertEqual(r["meta"]["dispatch"]["handoff"]["reason"], "clarification-did-not-resolve")

    def test_two_missing_slots_goes_to_live_agent(self):
        sid = self.new("M1003")  # PPO, no memory -> providerType and networkTier missing
        r = self.turn(sid, "What's my specialist copay?")
        self.assertEqual(r["meta"]["outcome"], "live-agent-transfer")
        self.assertEqual(r["meta"]["dispatch"]["handoff"]["reason"], "no-single-decisive-slot")

    def test_unidentified_question_goes_to_live_agent(self):
        sid = self.new("M1001")
        r = self.turn(sid, "Why was my claim from the hospital adjusted?")
        self.assertEqual(r["meta"]["outcome"], "live-agent-transfer")

    def test_benefit_not_in_system_of_record_goes_to_live_agent(self):
        sid = self.new("M1001")
        r = self.turn(sid, "What's my in-network copay for an allergist?")
        self.assertEqual(r["meta"]["outcome"], "live-agent-transfer")
        self.assertEqual(r["meta"]["dispatch"]["handoff"]["reason"], "benefits-agent-could-not-verify")
        self.assertNotIn("$", r["text"])

    def test_inactive_member_goes_to_live_agent(self):
        sid = self.new("M1004")
        r = self.turn(sid, "What is my deductible?")
        self.assertEqual(r["meta"]["outcome"], "live-agent-transfer")

    def test_benefits_agent_rejects_raw_utterance(self):
        from a2a_protocol.protocol import A2AClient, make_message, text_part
        benefits = self.agents[3]
        t = A2AClient(benefits.url).send_message(make_message("user", [text_part("what's my copay?")]))
        self.assertEqual(t["status"]["state"], "rejected")

    # --- Other intents -----------------------------------------------------------
    def test_hmo_network_grounded_from_plan_rule(self):
        sid = self.new("M1002")
        r = self.turn(sid, "How much is my deductible?")
        self.assertEqual(r["meta"]["outcome"], "answered")
        self.assertEqual(r["meta"]["resolution"]["slotEvidence"]["networkTier"]["source"], "profile")

    def test_prior_auth_synonym_and_rx(self):
        sid = self.new("M1001")
        r = self.turn(sid, "Do I need pre-approval for an MRI?")
        self.assertEqual(r["meta"]["resolution"]["resolvedIntent"], "CheckPriorAuthorization")
        self.assertTrue(r["text"].startswith("Yes"))
        r2 = self.turn(sid, "Is my Lipitor covered?")
        self.assertEqual(r2["meta"]["outcome"], "answered")
        self.assertIn("Atorvastatin", r2["text"])

    def test_phi_redacted_before_storage(self):
        sid = self.new("M1001")
        self.turn(sid, "My SSN is 123-45-6789, what is my ER copay?")
        stored = self.store.messages(sid)[0]["text"]
        self.assertNotIn("123-45-6789", stored)
        self.assertIn("[SSN_TOKEN_1]", stored)

    def test_client_cannot_lower_threshold(self):
        from a2a_protocol.protocol import A2AClient, data_part, make_message, artifact_data
        d = self.agents[1]
        t = A2AClient(d.url).send_message(make_message("user", [data_part({
            "utterance": "what's my specialist copay", "confidenceThreshold": 0.1,
            "memberContext": {"memberToken": "[MEMBER_ID_TOKEN_3]", "planId": "PPO-GOLD-2026", "planType": "PPO",
                              "eligibility": "active", "coverage": {"planYear": "2026"},
                              "authorizationScope": ["benefits:read"]}})]))
        res = artifact_data(t, "disambiguation-result")
        self.assertNotEqual(res["dispatchState"], "released")
        self.assertTrue(res["trace"]["clientThresholdIgnored"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
